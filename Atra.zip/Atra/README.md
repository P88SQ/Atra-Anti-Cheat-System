# Atra AntiCheat

Fejlett AntiCheat plugin Minecraft szerverekhez, amely prediction-based detection-t használ a cheaterek ellen.

## Funkciók

### Combat Checks
- **Reach** - Hatótáv ellenőrzés ping kompenzációval
- **KillAura** - Rotation analysis és multi-target detection
- **AutoClicker** - CPS tracking és click pattern analysis
- **Velocity** - Knockback manipulation detection
- **Criticals** - Fake critical hit detection
- **AimAssist** - GCD pattern és rotation consistency check

### Movement Checks
- **Fly** - Gravity check és air time tracking
- **Speed** - Server-side movement replication
- **NoClip** - Collision detection és phase check
- **Step** - Invalid step height detection
- **Jesus** - Water walking detection
- **Elytra** - Elytra flight manipulation check

### Packet Checks
- **Timer** - Packet rate analysis
- **BadPackets** - Invalid packet data detection
- **PingSpoofer** - Ping manipulation detection
- **InvalidMotion** - Motion value validation

### Misc Checks
- **Scaffold** - Fast block placement detection
- **FastBreak** - Block break speed check
- **Inventory** - Inventory manipulation detection
- **AutoTool** - Automatic tool switching detection

## Telepítés

1. Töltsd le a ProtocolLib plugint
2. Másold be mindkét JAR fájlt a `plugins` mappába
3. Indítsd újra a szervert
4. Konfiguráld a `config.yml` fájlt

## Parancsok

- `/atra` - Command help
- `/atra reload` - Reloads the config
- `/atra alerts` - Toggles the alerts
- `/atra version` - View version info
- `/atra debug` - Performance analysis
- `/atra info <player>` - Get user's info
- `/atra reset <player> [check]` - Reset violations

## Auto-Update Rendszer

A plugin automatikusan ellenőrzi az új verziókat a Spigot-on:
- Ellenőrzés indításkor
- Automatikus ellenőrzés 6 óránként
- Admin értesítés belépéskor ha új verzió elérhető
- Letöltési link: https://www.spigotmc.org/resources/130303/

## Jogosultságok

- `atra.bypass` - Bypass minden check-et
- `atra.alerts` - Alert-ek fogadása
- `atra.info` - Játékos információk megtekintése
- `atra.reset` - Violation-ök resetelése
- `atra.reload` - Config újratöltése
- `atra.admin` - Admin jogosultságok

## Konfiguráció

### VL (Violation Level) Rendszer

A plugin VL (Violation Level) rendszert használ:
- Kis gyanús tevékenység: +1-5 VL
- Közepes gyanús tevékenység: +5-10 VL
- Nagy gyanús tevékenység: +10-50 VL

VL decay: -1 VL minden 2 másodpercben legitim játék közben

### Büntetés Küszöbök

- **20 VL**: Setback (visszahelyezés)
- **50 VL**: Kick
- **100 VL**: Ban (7 nap)

### Lag Compensation

A plugin automatikusan kompenzálja a lag-et:
- Ping tracking minden játékosra
- Mozgás tolerancia növelése magas ping esetén
- Packet loss detection

## API Használat

```java
// PlayerData lekérése
PlayerData data = AtraAPI.getPlayerData(player);

// Check lekérése
Check check = AtraAPI.getCheck("reach");

// Violation resetelése
AtraAPI.resetViolations(player, "reach");
AtraAPI.resetAllViolations(player);
```

### Custom Event-ek

```java
@EventHandler
public void onFlag(FlagEvent event) {
    Player player = event.getPlayer();
    Check check = event.getCheck();
    String info = event.getInformation();
    
    // Custom logic
    event.setCancelled(true); // Cancel flag
}

@EventHandler
public void onViolation(ViolationEvent event) {
    int violations = event.getViolations();
    // Custom logic
}

@EventHandler
public void onPunish(PunishEvent event) {
    PunishmentType type = event.getPunishmentType();
    // Custom logic
}
```

## Technikai Részletek

### Prediction-Based Detection

A plugin server-side movement prediction-t használ:
- Vanilla Minecraft fizika szimulációja
- Collision detection
- Velocity tracking
- Multi-tick analysis

### False Positive Minimalizálás

- Whitelisting: Admin permission bypass
- Grace period: Új játékosok első 5-10 perce engedékenyebb
- Server lag detection: TPS <18 → lazább ellenőrzés
- Ping compensation: Automatikus tolerancia növelés

## Követelmények

- Paper/Spigot 1.21+
- Java 21+
- ProtocolLib 5.1.0+

## Licensz

Minden jog fenntartva © 2024 Draxel
