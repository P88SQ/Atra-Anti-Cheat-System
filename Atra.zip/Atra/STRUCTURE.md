# Atra AntiCheat - Projekt Struktúra

## Teljes Fájl Struktúra

```
src/main/java/dev/draxel/atra/
│
├── AtraAC.java                          // Fő plugin class (JavaPlugin)
│
├── api/
│   ├── AtraAPI.java                     // Publikus API más pluginoknak
│   ├── events/
│   │   ├── FlagEvent.java               // Custom event amikor játékos flag-elve van
│   │   ├── ViolationEvent.java          // VL növekedés event
│   │   └── PunishEvent.java             // Büntetés event
│   └── interfaces/
│       ├── ICheck.java                  // Check interface
│       └── IPlayerData.java             // PlayerData interface
│
├── check/
│   ├── CheckManager.java                // Check-ok kezelése, regisztráció
│   ├── CheckType.java                   // Enum: COMBAT, MOVEMENT, PACKET, MISC
│   ├── Check.java                       // Abstract base check class
│   │
│   ├── combat/
│   │   ├── KillAuraCheck.java           // Rotation analysis, multi-target
│   │   ├── ReachCheck.java              // Hatótáv ellenőrzés
│   │   ├── AutoClickerCheck.java        // CPS és click pattern
│   │   ├── VelocityCheck.java           // Knockback detection
│   │   ├── CriticalsCheck.java          // Fake critical detection
│   │   └── AimAssistCheck.java          // GCD pattern analysis
│   │
│   ├── movement/
│   │   ├── FlyCheck.java                // Gravity check
│   │   ├── SpeedCheck.java              // Movement prediction
│   │   ├── NoClipCheck.java             // Collision detection
│   │   ├── StepCheck.java               // Step height check
│   │   ├── JesusCheck.java              // Water walking
│   │   └── ElytraCheck.java             // Elytra manipulation
│   │
│   ├── packet/
│   │   ├── TimerCheck.java              // Packet rate analysis
│   │   ├── BadPacketsCheck.java         // Invalid packet data
│   │   ├── PingSpooferCheck.java        // Ping manipulation
│   │   └── InvalidMotionCheck.java      // Motion validation
│   │
│   └── misc/
│       ├── InventoryCheck.java          // Inventory manipulation
│       ├── ScaffoldCheck.java           // Fast block placement
│       ├── AutoToolCheck.java           // Tool switching
│       └── FastBreakCheck.java          // Block break speed
│
├── data/
│   ├── PlayerDataManager.java           // Játékos adatok kezelése
│   ├── PlayerData.java                  // Egy játékos összes adata
│   ├── ViolationData.java               // VL tracking check-enként
│   ├── CombatData.java                  // Combat specifikus adatok
│   ├── MovementData.java                // Mozgás tracking
│   └── ClickData.java                   // Kattintás pattern adatok
│
├── prediction/
│   ├── MovementPredictor.java           // Mozgás prediction
│   ├── PhysicsEngine.java               // Minecraft fizika szimuláció
│   ├── CollisionHandler.java            // Ütközés számítás
│   └── VelocityTracker.java             // Velocity változások követése
│
├── listener/
│   ├── PacketListener.java              // ProtocolLib packet listening
│   ├── PlayerListener.java              // Bukkit player events
│   ├── CombatListener.java              // Combat events
│   └── MovementListener.java            // Movement events
│
├── punishment/
│   ├── PunishmentManager.java           // Büntetések kezelése
│   ├── PunishmentType.java              // Enum: KICK, BAN, SETBACK, ALERT
│   ├── ViolationThreshold.java          // VL threshold config check-enként
│   └── ActionHandler.java               // Action végrehajtás
│
├── alert/
│   ├── AlertManager.java                // Staff alert rendszer
│   ├── AlertMessage.java                // Alert üzenet formázás
│   └── AlertQueue.java                  // Alert spam megelőzés
│
├── config/
│   ├── ConfigManager.java               // Config kezelés
│   ├── CheckConfig.java                 // Check-specifikus beállítások
│   ├── MessagesConfig.java              // Üzenetek config
│   └── SettingsConfig.java              // Általános beállítások
│
├── command/
│   ├── AtraCommand.java                 // Fő command handler
│   ├── CommandManager.java              // Subcommand routing
│   └── subcommands/
│       ├── SubCommand.java              // Interface
│       ├── AlertsCommand.java           // /atra alerts
│       ├── InfoCommand.java             // /atra info <player>
│       ├── ResetCommand.java            // /atra reset <player>
│       ├── DebugCommand.java            // /atra debug
│       └── ReloadCommand.java           // /atra reload
│
├── util/
│   ├── Logger.java                      // Custom logging
│   ├── MathUtil.java                    // Matematikai segédfüggvények
│   ├── PlayerUtil.java                  // Játékos utility metódusok
│   ├── LocationUtil.java                // Pozíció számítások
│   ├── TickUtil.java                    // Tick/timing utility
│   ├── PacketUtil.java                  // Packet helper methods
│   ├── PermissionUtil.java              // Permission ellenőrzés
│   └── ColorUtil.java                   // Chat color formatting
│
├── storage/
│   ├── StorageManager.java              // Adatbázis/file kezelés
│   ├── FlatFileStorage.java             // YAML/JSON storage
│   ├── SQLStorage.java                  // MySQL/SQLite storage
│   └── LogStorage.java                  // Log file írás/olvasás
│
└── gui/
    ├── MenuManager.java                 // GUI menük kezelése
    ├── PlayerInfoGUI.java               // Játékos info GUI
    ├── ViolationsGUI.java               // VL history GUI
    └── ChecksGUI.java                   // Check enable/disable GUI
```

## Resources

```
src/main/resources/
│
├── plugin.yml                           // Plugin metadata
├── config.yml                           // Főconfig
├── checks.yml                           // Check beállítások
├── messages.yml                         // Üzenetek
└── punishments.yml                      // Büntetés konfiguráció
```

## Főbb Komponensek

### 1. Check Rendszer
- **18 különböző check** 4 kategóriában
- Prediction-based detection
- VL (Violation Level) rendszer
- Automatikus decay

### 2. Data Tracking
- Real-time player data tracking
- Combat statistics (CPS, reach, rotation)
- Movement history (velocity, position)
- Click pattern analysis

### 3. Punishment System
- Threshold-based punishments
- Setback, Kick, Ban
- Customizable per check
- Event-driven architecture

### 4. Alert System
- Real-time staff notifications
- Spam prevention
- Detailed information
- Toggle-able per staff member

### 5. API
- Public API for other plugins
- Custom events (Flag, Violation, Punish)
- PlayerData access
- Check management

## Technológiák

- **Paper API 1.21.4**
- **ProtocolLib 5.1.0** - Packet manipulation
- **Java 21** - Modern Java features
- **Gradle** - Build system

## Check Implementációk

### Combat Checks
- **Reach**: Ray-tracing, hitbox calculation, ping compensation
- **KillAura**: Rotation analysis, multi-target detection, impossible rotations
- **AutoClicker**: CPS tracking, standard deviation, pattern analysis
- **Velocity**: Multi-tick tracking, expected vs actual velocity
- **Criticals**: Fall distance check, liquid detection, ground validation
- **AimAssist**: GCD patterns, rotation consistency, variance analysis

### Movement Checks
- **Fly**: Gravity simulation, air time tracking, Y-velocity analysis
- **Speed**: Server-side replication, friction simulation, effect modifiers
- **NoClip**: Collision detection, ray-casting, setback mechanism
- **Step**: Height validation, jump distinction, block checking
- **Jesus**: Water detection, flight exclusion
- **Elytra**: Hover detection, velocity patterns

### Packet Checks
- **Timer**: Packet rate measurement, burst detection
- **BadPackets**: Invalid pitch, NaN/Infinite values
- **PingSpoofer**: Reported vs actual ping comparison
- **InvalidMotion**: Motion value validation, impossible speeds

### Misc Checks
- **Scaffold**: Fast placement, rotation analysis, speed correlation
- **FastBreak**: Break timing, minimum intervals
- **Inventory**: Action timing, impossible speeds
- **AutoTool**: Tool switching patterns (basic implementation)

## Konfigurálhatóság

Minden check külön konfigurálható:
- Enable/disable
- Max violations
- Check-specific thresholds
- Punishment levels
- Tolerances

## False Positive Megelőzés

- Ping compensation
- Server lag detection (TPS monitoring)
- Grace period új játékosoknak
- Bypass permission
- Multi-tick analysis
- Statistical methods
