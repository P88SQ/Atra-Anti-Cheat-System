package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.CombatData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class ReachCheck extends Check {
    
    private static final double MAX_REACH_SURVIVAL = 3.0;
    private static final double MAX_REACH_CREATIVE = 6.0;
    private static final double TOLERANCE = 0.25;
    
    public ReachCheck(AtraAC plugin) {
        super(plugin, "Reach", CheckType.COMBAT);
    }
    
    public void checkReach(Player player, Entity target) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        CombatData combatData = data.getCombatData();
        
        double distance = player.getLocation().distance(target.getLocation());
        double maxReach = player.getGameMode() == GameMode.CREATIVE ? MAX_REACH_CREATIVE : MAX_REACH_SURVIVAL;
        
        // Ping compensation
        int ping = player.getPing();
        double pingCompensation = (ping / 1000.0) * 0.3;
        maxReach += pingCompensation + TOLERANCE;
        
        combatData.addReach(distance);
        
        if (distance > maxReach) {
            double excess = distance - (maxReach - TOLERANCE);
            flag(player, String.format("Reach: %.2f blocks (max: %.2f)", distance, maxReach - TOLERANCE), 
                 (int) (excess * 10));
        }
    }
}
