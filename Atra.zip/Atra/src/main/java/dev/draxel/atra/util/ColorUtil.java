package dev.draxel.atra.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;

public class ColorUtil {
    
    private static final MiniMessage miniMessage = MiniMessage.miniMessage();
    
    public static Component translate(String message) {
        return miniMessage.deserialize(message).decoration(TextDecoration.ITALIC, false);
    }
    
    public static String color(String message) {
        return message.replaceAll("&([0-9a-fk-or])", "§$1");
    }
    
    public static String strip(String message) {
        return message.replaceAll("§[0-9a-fk-or]", "");
    }
}
