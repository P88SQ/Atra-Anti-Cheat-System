package dev.draxel.atra.gui;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ChecksGUI implements MenuManager.GUI {
    
    private final AtraAC plugin;
    
    public ChecksGUI(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, 
            Component.text("Atra - Checks"));
        
        int slot = 0;
        for (Check check : plugin.getCheckManager().getChecks()) {
            ItemStack item = new ItemStack(
                check.isEnabled() ? Material.LIME_DYE : Material.GRAY_DYE
            );
            
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text(check.getName()));
            item.setItemMeta(meta);
            
            inv.setItem(slot++, item);
        }
        
        player.openInventory(inv);
    }
}
