package dev.draxel.atra.util;

import dev.draxel.atra.AtraAC;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;

public class Logger {
    
    private static final String PREFIX = "§8[§cAtra§8]§r ";
    
    public static void info(String message) {
        AtraAC.getInstance().getLogger().info(ChatColor.stripColor(message));
    }
    
    public static void warning(String message) {
        AtraAC.getInstance().getLogger().warning(ChatColor.stripColor(message));
    }
    
    public static void severe(String message) {
        AtraAC.getInstance().getLogger().severe(ChatColor.stripColor(message));
    }
    
    public static void debug(String message) {
        if (AtraAC.getInstance().getConfigManager().isDebugEnabled()) {
            info("[DEBUG] " + message);
        }
    }
    
    public static void console(String message) {
        Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
    }
    
    public static void loader(String message) {
        console("§8[§bAtra§8] §r" + message);
    }
}
