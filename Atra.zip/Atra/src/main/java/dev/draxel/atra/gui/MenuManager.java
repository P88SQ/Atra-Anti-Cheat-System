package dev.draxel.atra.gui;

import dev.draxel.atra.AtraAC;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MenuManager {
    
    private final AtraAC plugin;
    private final Map<UUID, GUI> openMenus;
    
    public MenuManager(AtraAC plugin) {
        this.plugin = plugin;
        this.openMenus = new HashMap<>();
    }
    
    public void openMenu(Player player, GUI gui) {
        openMenus.put(player.getUniqueId(), gui);
        gui.open(player);
    }
    
    public void closeMenu(Player player) {
        openMenus.remove(player.getUniqueId());
    }
    
    public GUI getOpenMenu(Player player) {
        return openMenus.get(player.getUniqueId());
    }
    
    public interface GUI {
        void open(Player player);
    }
}
