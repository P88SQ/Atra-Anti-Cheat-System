package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class JesusCheck extends Check {
    
    public JesusCheck(AtraAC plugin) {
        super(plugin, "Jesus", CheckType.MOVEMENT);
    }
    
    public void checkJesus(Player player) {
        if (!enabled) return;
        
        Block blockBelow = player.getLocation().subtract(0, 0.1, 0).getBlock();
        
        if (blockBelow.getType() == Material.WATER && !player.isInWater() && 
            !player.isGliding() && !player.getAllowFlight()) {
            
            flag(player, "Walking on water", 15);
        }
    }
}
