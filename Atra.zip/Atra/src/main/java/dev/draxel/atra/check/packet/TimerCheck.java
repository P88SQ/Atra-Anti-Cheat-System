package dev.draxel.atra.check.packet;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;

public class TimerCheck extends Check {
    
    private static final int MAX_PACKETS_PER_SECOND = 80;
    
    public TimerCheck(AtraAC plugin) {
        super(plugin, "Timer", CheckType.PACKET);
    }
    
    public void checkTimer(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        
        long currentTime = System.currentTimeMillis();
        long timeDiff = currentTime - data.getLastPacketTime();
        
        if (timeDiff >= 1000) {
            int packetsPerSecond = data.getPacketCount();
            
            if (packetsPerSecond > MAX_PACKETS_PER_SECOND) {
                flag(player, String.format("High packet rate: %d/s", packetsPerSecond), 10);
            }
            
            data.resetPacketCount();
        }
    }
}
