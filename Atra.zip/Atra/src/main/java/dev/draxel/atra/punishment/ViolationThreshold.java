package dev.draxel.atra.punishment;

public class ViolationThreshold {
    
    private final String checkName;
    private final int alertThreshold;
    private final int setbackThreshold;
    private final int kickThreshold;
    private final int banThreshold;
    
    public ViolationThreshold(String checkName, int alertThreshold, int setbackThreshold, 
                             int kickThreshold, int banThreshold) {
        this.checkName = checkName;
        this.alertThreshold = alertThreshold;
        this.setbackThreshold = setbackThreshold;
        this.kickThreshold = kickThreshold;
        this.banThreshold = banThreshold;
    }
    
    public String getCheckName() {
        return checkName;
    }
    
    public int getAlertThreshold() {
        return alertThreshold;
    }
    
    public int getSetbackThreshold() {
        return setbackThreshold;
    }
    
    public int getKickThreshold() {
        return kickThreshold;
    }
    
    public int getBanThreshold() {
        return banThreshold;
    }
    
    public PunishmentType getPunishmentType(int violations) {
        if (violations >= banThreshold) {
            return PunishmentType.BAN;
        } else if (violations >= kickThreshold) {
            return PunishmentType.KICK;
        } else if (violations >= setbackThreshold) {
            return PunishmentType.SETBACK;
        } else if (violations >= alertThreshold) {
            return PunishmentType.ALERT;
        }
        return PunishmentType.ALERT;
    }
}
