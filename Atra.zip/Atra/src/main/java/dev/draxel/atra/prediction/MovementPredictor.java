package dev.draxel.atra.prediction;

import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.util.PlayerUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;

public class MovementPredictor {
    
    private final PhysicsEngine physicsEngine;
    private final CollisionHandler collisionHandler;
    
    // Advanced prediction data
    public static class PredictionResult {
        public final Vector predictedVelocity;
        public final Location predictedLocation;
        public final double confidence;
        public final String reason;
        public final boolean isPossible;
        public final double maxSpeed;
        public final double predictedSpeed;
        
        public PredictionResult(Vector velocity, Location location, double confidence, String reason) {
            this.predictedVelocity = velocity;
            this.predictedLocation = location;
            this.confidence = confidence;
            this.reason = reason;
            this.isPossible = true;
            this.maxSpeed = 0.5;
            this.predictedSpeed = velocity.length();
        }
        
        public PredictionResult(Vector velocity, Location location, double confidence, String reason, boolean isPossible, double maxSpeed, double predictedSpeed) {
            this.predictedVelocity = velocity;
            this.predictedLocation = location;
            this.confidence = confidence;
            this.reason = reason;
            this.isPossible = isPossible;
            this.maxSpeed = maxSpeed;
            this.predictedSpeed = predictedSpeed;
        }
    }
    
    public MovementPredictor() {
        this.physicsEngine = new PhysicsEngine();
        this.collisionHandler = new CollisionHandler();
    }
    
    /**
     * Advanced multi-tick prediction with confidence scoring
     */
    public PredictionResult predictNextMovement(Player player, MovementData movementData) {
        if (movementData.getCurrentLocation() == null || movementData.getLastVelocity() == null) {
            return new PredictionResult(
                new Vector(0, 0, 0),
                player.getLocation(),
                0.0,
                "Insufficient data"
            );
        }
        
        Location current = movementData.getCurrentLocation();
        Vector velocity = movementData.getLastVelocity().clone();
        boolean onGround = player.isOnGround();
        
        // Calculate confidence based on data quality
        double confidence = calculateConfidence(movementData, player);
        
        // Apply physics simulation
        Vector predictedVelocity = physicsEngine.applyPhysics(player, velocity, onGround);
        
        // Check for collisions
        Location predictedLocation = current.clone().add(predictedVelocity);
        if (collisionHandler.hasCollision(current, predictedLocation)) {
            // Adjust for collision
            predictedVelocity = adjustForCollision(current, predictedVelocity);
            predictedLocation = current.clone().add(predictedVelocity);
            confidence *= 0.9; // Reduce confidence due to collision
        }
        
        return new PredictionResult(
            predictedVelocity,
            predictedLocation,
            confidence,
            "Standard prediction"
        );
    }
    
    /**
     * Multi-tick ahead prediction (predicts N ticks into the future)
     */
    public Deque<Location> predictPath(Player player, MovementData movementData, int ticks) {
        Deque<Location> path = new ArrayDeque<>();
        
        if (movementData.getCurrentLocation() == null || movementData.getLastVelocity() == null) {
            return path;
        }
        
        Location current = movementData.getCurrentLocation().clone();
        Vector velocity = movementData.getLastVelocity().clone();
        boolean onGround = player.isOnGround();
        
        for (int i = 0; i < ticks; i++) {
            // Apply physics
            velocity = physicsEngine.applyPhysics(player, velocity, onGround);
            
            // Calculate next position
            Location next = current.clone().add(velocity);
            
            // Check collision
            if (collisionHandler.hasCollision(current, next)) {
                velocity = adjustForCollision(current, velocity);
                next = current.clone().add(velocity);
                onGround = true;
            } else {
                onGround = false;
            }
            
            path.add(next);
            current = next;
        }
        
        return path;
    }
    
    /**
     * Calculate prediction confidence based on data quality
     */
    private double calculateConfidence(MovementData movementData, Player player) {
        double confidence = 1.0;
        
        // Reduce confidence if velocity history is short
        if (movementData.getVelocityHistory().size() < 5) {
            confidence *= 0.7;
        }
        
        // Reduce confidence for high ping
        int ping = PlayerUtil.getPing(player);
        if (ping > 100) {
            confidence *= Math.max(0.5, 1.0 - (ping / 1000.0));
        }
        
        // Reduce confidence if player is in special state
        if (PlayerUtil.isSwimming(player) || PlayerUtil.isRiptiding(player)) {
            confidence *= 0.8;
        }
        
        // Reduce confidence if velocity is inconsistent
        if (isVelocityInconsistent(movementData)) {
            confidence *= 0.6;
        }
        
        return Math.max(0.1, confidence);
    }
    
    /**
     * Check if velocity pattern is inconsistent (possible teleport/lag)
     */
    private boolean isVelocityInconsistent(MovementData movementData) {
        if (movementData.getVelocityHistory().size() < 3) {
            return false;
        }
        
        Vector[] recent = movementData.getVelocityHistory().toArray(new Vector[0]);
        int size = recent.length;
        
        if (size < 3) return false;
        
        // Check last 3 velocities for sudden changes
        Vector v1 = recent[size - 1];
        Vector v2 = recent[size - 2];
        Vector v3 = recent[size - 3];
        
        double change1 = v1.distance(v2);
        double change2 = v2.distance(v3);
        
        // If change is more than 2x, it's inconsistent
        return change1 > change2 * 2.0 || change2 > change1 * 2.0;
    }
    
    /**
     * Adjust velocity for collision
     */
    private Vector adjustForCollision(Location from, Vector velocity) {
        Vector adjusted = velocity.clone();
        
        // Check each axis separately
        Location testX = from.clone().add(velocity.getX(), 0, 0);
        if (collisionHandler.isSolid(testX)) {
            adjusted.setX(0);
        }
        
        Location testY = from.clone().add(0, velocity.getY(), 0);
        if (collisionHandler.isSolid(testY)) {
            adjusted.setY(0);
        }
        
        Location testZ = from.clone().add(0, 0, velocity.getZ());
        if (collisionHandler.isSolid(testZ)) {
            adjusted.setZ(0);
        }
        
        return adjusted;
    }
    
    /**
     * Legacy methods for compatibility
     */
    public Location predictNextLocation(Player player, MovementData movementData) {
        return predictNextMovement(player, movementData).predictedLocation;
    }
    
    public Vector predictVelocity(Player player, Vector currentVelocity, boolean onGround) {
        return physicsEngine.applyPhysics(player, currentVelocity, onGround);
    }
    
    public double getMaxPossibleSpeed(Player player) {
        return physicsEngine.calculateMaxSpeed(player);
    }
    
    /**
     * Calculate deviation between predicted and actual movement
     */
    public double calculateDeviation(Location predicted, Location actual) {
        if (predicted == null || actual == null) {
            return 0.0;
        }
        
        return predicted.distance(actual);
    }
    
    /**
     * Check if movement is possible given current state
     */
    public boolean isMovementPossible(Player player, MovementData movementData, Location target) {
        PredictionResult prediction = predictNextMovement(player, movementData);
        
        double deviation = calculateDeviation(prediction.predictedLocation, target);
        double maxDeviation = getMaxPossibleSpeed(player) * 1.5; // 50% tolerance
        
        return deviation <= maxDeviation;
    }
    
    /**
     * Predict movement with detailed result for checks
     */
    public PredictionResult predictMovement(Player player, MovementData movementData) {
        if (movementData.getCurrentLocation() == null || movementData.getLastVelocity() == null) {
            double maxSpeed = getMaxPossibleSpeed(player);
            return new PredictionResult(
                new Vector(0, 0, 0),
                player.getLocation(),
                0.0,
                "Insufficient data",
                true,
                maxSpeed,
                0.0
            );
        }
        
        Location current = movementData.getCurrentLocation();
        Vector velocity = movementData.getLastVelocity().clone();
        boolean onGround = player.isOnGround();
        
        // Calculate confidence based on data quality
        double confidence = calculateConfidence(movementData, player);
        
        // Apply physics simulation
        Vector predictedVelocity = physicsEngine.applyPhysics(player, velocity, onGround);
        double predictedSpeed = predictedVelocity.length();
        double maxSpeed = getMaxPossibleSpeed(player);
        
        // Check for collisions
        Location predictedLocation = current.clone().add(predictedVelocity);
        if (collisionHandler.hasCollision(current, predictedLocation)) {
            // Adjust for collision
            predictedVelocity = adjustForCollision(current, predictedVelocity);
            predictedLocation = current.clone().add(predictedVelocity);
            confidence *= 0.9; // Reduce confidence due to collision
        }
        
        // Determine if movement is possible
        boolean isPossible = predictedSpeed <= maxSpeed * 1.1; // 10% tolerance
        
        return new PredictionResult(
            predictedVelocity,
            predictedLocation,
            confidence,
            isPossible ? "Normal movement" : "Speed exceeds maximum",
            isPossible,
            maxSpeed,
            predictedSpeed
        );
    }
}
