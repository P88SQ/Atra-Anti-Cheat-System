package dev.draxel.atra.check.misc;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class FastBreakCheck extends Check {
    
    private final Map<UUID, Long> lastBreakTime = new HashMap<>();
    
    public FastBreakCheck(AtraAC plugin) {
        super(plugin, "FastBreak", CheckType.MISC);
    }
    
    public void checkBreak(Player player, Block block) {
        if (!enabled) return;
        if (player.getGameMode() == GameMode.CREATIVE) return;
        
        long currentTime = System.currentTimeMillis();
        long lastTime = lastBreakTime.getOrDefault(player.getUniqueId(), 0L);
        long timeDiff = currentTime - lastTime;
        
        // Minimum time between breaks (50ms = 1 tick)
        if (timeDiff < 50) {
            flag(player, String.format("Fast break: %dms between breaks", timeDiff), 10);
        }
        
        lastBreakTime.put(player.getUniqueId(), currentTime);
    }
}
