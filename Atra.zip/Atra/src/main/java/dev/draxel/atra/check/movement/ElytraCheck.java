package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;

public class ElytraCheck extends Check {
    
    public ElytraCheck(AtraAC plugin) {
        super(plugin, "Elytra", CheckType.MOVEMENT);
    }
    
    public void checkElytra(Player player) {
        if (!enabled || !player.isGliding()) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        if (movementData.getLastVelocity() == null) return;
        
        double yVelocity = movementData.getLastVelocity().getY();
        
        // Check for unnatural hovering
        if (Math.abs(yVelocity) < 0.01 && movementData.getAirTicks() > 20) {
            flag(player, "Elytra hovering detected", 10);
        }
    }
}
