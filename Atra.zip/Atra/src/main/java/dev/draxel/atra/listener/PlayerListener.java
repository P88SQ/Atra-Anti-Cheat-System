package dev.draxel.atra.listener;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.PermissionUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {
    
    private final AtraAC plugin;
    
    public PlayerListener(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Initialize player data
        plugin.getPlayerDataManager().getPlayerData(player);
        
        // Enable alerts for staff
        if (PermissionUtil.canSeeAlerts(player)) {
            plugin.getAlertManager().enableAlerts(player);
        }
        
        // Notify admins about updates
        if (PermissionUtil.isAdmin(player) && plugin.getUpdateChecker() != null) {
            if (plugin.getUpdateChecker().isUpdateAvailable()) {
                player.sendMessage("§8[§bAtra§8] §7━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                player.sendMessage("§8[§bAtra§8] §fNew update available!");
                player.sendMessage("§8[§bAtra§8] §7Current: §f" + plugin.getDescription().getVersion());
                player.sendMessage("§8[§bAtra§8] §7Latest: §a" + plugin.getUpdateChecker().getLatestVersion());
                player.sendMessage("§8[§bAtra§8] §7Download: §b" + plugin.getUpdateChecker().getSpigotUrl());
                player.sendMessage("§8[§bAtra§8] §7━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            }
        }
    }
    
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Save and remove player data
        plugin.getStorageManager().savePlayerData(player);
        plugin.getPlayerDataManager().removePlayerData(player.getUniqueId());
        
        // Disable alerts
        plugin.getAlertManager().disableAlerts(player);
    }
}
