package dev.draxel.atra.util.version;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

public class VersionAdapter {
    
    private static final ServerVersion VERSION = ServerVersion.getServerVersion();
    
    /**
     * Get the attack cooldown for a player (1.9+)
     */
    public static float getAttackCooldown(Player player) {
        if (VERSION.isOlderThan(ServerVersion.v1_9_R1)) {
            return 1.0f; // No cooldown in 1.8
        }
        
        try {
            return player.getAttackCooldown();
        } catch (NoSuchMethodError e) {
            return 1.0f;
        }
    }
    
    /**
     * Check if player is swimming (1.13+)
     */
    public static boolean isSwimming(Player player) {
        if (VERSION.isOlderThan(ServerVersion.v1_13_R1)) {
            return false; // No swimming in pre-1.13
        }
        
        try {
            return player.isSwimming();
        } catch (NoSuchMethodError e) {
            return false;
        }
    }
    
    /**
     * Check if player is riptiding (1.13+)
     */
    public static boolean isRiptiding(Player player) {
        if (VERSION.isOlderThan(ServerVersion.v1_13_R1)) {
            return false;
        }
        
        try {
            return player.isRiptiding();
        } catch (NoSuchMethodError e) {
            return false;
        }
    }
    
    /**
     * Get player's ping
     */
    public static int getPing(Player player) {
        try {
            return player.getPing();
        } catch (NoSuchMethodError e) {
            // Fallback for older versions
            return 0;
        }
    }
    
    /**
     * Check if player has slow falling effect (1.13+)
     */
    public static boolean hasSlowFalling(Player player) {
        if (VERSION.isOlderThan(ServerVersion.v1_13_R1)) {
            return false;
        }
        
        try {
            PotionEffectType slowFalling = PotionEffectType.getByName("SLOW_FALLING");
            return slowFalling != null && player.hasPotionEffect(slowFalling);
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Check if player has levitation effect
     */
    public static boolean hasLevitation(Player player) {
        if (VERSION.isOlderThan(ServerVersion.v1_9_R1)) {
            return false;
        }
        
        try {
            PotionEffectType levitation = PotionEffectType.getByName("LEVITATION");
            return levitation != null && player.hasPotionEffect(levitation);
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Get server version
     */
    public static ServerVersion getVersion() {
        return VERSION;
    }
    
    /**
     * Check if version is supported
     */
    public static boolean isSupported() {
        return VERSION != ServerVersion.UNKNOWN;
    }
    
    /**
     * Get version string for display
     */
    public static String getVersionString() {
        return VERSION.getVersionString();
    }
}
