package dev.draxel.atra.util;

import java.util.Collection;

public class MathUtil {
    
    public static double getStandardDeviation(Collection<Long> values) {
        if (values.isEmpty()) return 0.0;
        
        double mean = getAverage(values);
        double variance = 0.0;
        
        for (long value : values) {
            variance += Math.pow(value - mean, 2);
        }
        
        return Math.sqrt(variance / values.size());
    }
    
    public static double getAverage(Collection<Long> values) {
        if (values.isEmpty()) return 0.0;
        
        long sum = 0;
        for (long value : values) {
            sum += value;
        }
        
        return (double) sum / values.size();
    }
    
    public static double getGcd(double a, double b) {
        if (a < b) {
            return getGcd(b, a);
        }
        
        if (Math.abs(b) < 0.001) {
            return a;
        } else {
            return getGcd(b, a - Math.floor(a / b) * b);
        }
    }
    
    public static double getVariance(Collection<Double> values) {
        if (values.isEmpty()) return 0.0;
        
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double variance = 0.0;
        
        for (double value : values) {
            variance += Math.pow(value - mean, 2);
        }
        
        return variance / values.size();
    }
    
    public static double getKurtosis(Collection<Double> values) {
        if (values.size() < 4) return 0.0;
        
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double variance = getVariance(values);
        
        if (variance == 0) return 0.0;
        
        double sum = 0.0;
        for (double value : values) {
            sum += Math.pow((value - mean) / Math.sqrt(variance), 4);
        }
        
        return (sum / values.size()) - 3.0;
    }
}
