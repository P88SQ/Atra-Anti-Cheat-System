package dev.draxel.atra.prediction;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public class CollisionHandler {
    
    private static final double PLAYER_WIDTH = 0.6;
    private static final double PLAYER_HEIGHT = 1.8;
    
    public boolean hasCollision(Location from, Location to) {
        Vector direction = to.toVector().subtract(from.toVector()).normalize();
        double distance = from.distance(to);
        
        // Ray-cast from -> to
        for (double d = 0; d <= distance; d += 0.1) {
            Location check = from.clone().add(direction.clone().multiply(d));
            
            if (isSolid(check)) {
                return true;
            }
        }
        
        return false;
    }
    
    public boolean isSolid(Location location) {
        Block block = location.getBlock();
        return block.getType().isSolid() && !block.getType().isInteractable();
    }
    
    public BoundingBox getPlayerBoundingBox(Location location) {
        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();
        
        double halfWidth = PLAYER_WIDTH / 2;
        
        return new BoundingBox(
            x - halfWidth, y, z - halfWidth,
            x + halfWidth, y + PLAYER_HEIGHT, z + halfWidth
        );
    }
    
    public boolean isInsideBlock(Location location) {
        BoundingBox playerBox = getPlayerBoundingBox(location);
        
        int minX = (int) Math.floor(playerBox.getMinX());
        int minY = (int) Math.floor(playerBox.getMinY());
        int minZ = (int) Math.floor(playerBox.getMinZ());
        int maxX = (int) Math.floor(playerBox.getMaxX());
        int maxY = (int) Math.floor(playerBox.getMaxY());
        int maxZ = (int) Math.floor(playerBox.getMaxZ());
        
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block block = location.getWorld().getBlockAt(x, y, z);
                    if (block.getType().isSolid() && !block.getType().isInteractable()) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
}
