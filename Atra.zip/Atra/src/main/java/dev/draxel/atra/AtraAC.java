package dev.draxel.atra;

import dev.draxel.atra.alert.AlertManager;
import dev.draxel.atra.check.CheckManager;
import dev.draxel.atra.command.AtraCommand;
import dev.draxel.atra.config.ConfigManager;
import dev.draxel.atra.data.PlayerDataManager;
import dev.draxel.atra.listener.CombatListener;
import dev.draxel.atra.listener.MovementListener;
import dev.draxel.atra.listener.PacketListener;
import dev.draxel.atra.listener.PlayerListener;
import dev.draxel.atra.punishment.PunishmentManager;
import dev.draxel.atra.storage.StorageManager;
import dev.draxel.atra.util.Logger;
import org.bukkit.plugin.java.JavaPlugin;

public class AtraAC extends JavaPlugin {
    
    private static AtraAC instance;
    
    private ConfigManager configManager;
    private CheckManager checkManager;
    private PlayerDataManager playerDataManager;
    private PunishmentManager punishmentManager;
    private AlertManager alertManager;
    private StorageManager storageManager;
    private PacketListener packetListener;
    private dev.draxel.atra.util.update.UpdateChecker updateChecker;
    
    @Override
    public void onEnable() {
        long startTime = System.currentTimeMillis();
        instance = this;
        
        // ASCII Art Banner
        printBanner();
        
        printLoader("§b> §fInitializing Atra AntiCheat...");
        
        // Config inicializálás
        configManager = new ConfigManager(this);
        configManager.loadConfigs();
        printLoader("§b> §fConfiguration loaded");
        
        // Manager-ek inicializálása
        storageManager = new StorageManager(this);
        printLoader("§b> §fStorage manager initialized");
        
        playerDataManager = new PlayerDataManager(this);
        printLoader("§b> §fPlayer data manager initialized");
        
        checkManager = new CheckManager(this);
        printLoader("§b> §fCheck manager initialized");
        
        punishmentManager = new PunishmentManager(this);
        printLoader("§b> §fPunishment manager initialized");
        
        alertManager = new AlertManager(this);
        printLoader("§b> §fAlert manager initialized");
        
        // Check-ok regisztrálása
        checkManager.registerChecks();
        printLoader("§b> §f" + checkManager.getChecks().size() + " checks registered");
        
        // Listener-ek regisztrálása
        registerListeners();
        printLoader("§b> §fEvent listeners registered");
        
        // Packet listener inicializálás
        if (getServer().getPluginManager().getPlugin("ProtocolLib") != null) {
            packetListener = new PacketListener(this);
            packetListener.register();
            printLoader("§b> §fProtocolLib integration enabled");
        } else {
            printLoader("§c> §fProtocolLib not found! Packet checks disabled");
        }
        
        // Command regisztráció
        getCommand("atra").setExecutor(new AtraCommand(this));
        printLoader("§b> §fCommands registered");
        
        // Server version detection
        detectServerVersion();
        
        // ViaVersion detection
        detectVersionPlugins();
        
        // Update checker
        if (configManager.getConfig().getBoolean("update-checker.enabled", true)) {
            updateChecker = new dev.draxel.atra.util.update.UpdateChecker(this);
            
            updateChecker.checkForUpdates().thenAccept(result -> {
                if (result.isUpdateAvailable()) {
                    printLoader("§e> §fNew update available: §a" + result.getLatestVersion());
                    printLoader("§e> §fDownload: §b" + result.getDownloadUrl());
                }
            });
            
            // Start auto-check (every 6 hours)
            if (configManager.getConfig().getBoolean("update-checker.notify-admins", true)) {
                updateChecker.startAutoCheck();
                printLoader("§b> §fUpdate checker enabled");
            }
        }
        
        long loadTime = System.currentTimeMillis() - startTime;
        printLoader("");
        printLoader("§a> §fSuccessfully loaded in §b" + loadTime + "ms");
        printLoader("§a> §fAtra AntiCheat v" + getDescription().getVersion() + " is now active!");
        printLoader("");
        printCheckSummary();
        printServerInfo();
    }
    
    @Override
    public void onDisable() {
        printLoader("§c> §fShutting down Atra AntiCheat...");
        
        // Packet listener leállítás
        if (packetListener != null) {
            packetListener.unregister();
            printLoader("§c> §fPacket listener unregistered");
        }
        
        // Adatok mentése
        if (storageManager != null) {
            storageManager.saveAll();
            printLoader("§c> §fData saved");
        }
        
        // PlayerData cleanup
        if (playerDataManager != null) {
            playerDataManager.cleanup();
            printLoader("§c> §fPlayer data cleared");
        }
        
        printLoader("§c> §fAtra AntiCheat disabled!");
    }
    
    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new MovementListener(this), this);
        
        // Initialize behavior analysis listener
        new dev.draxel.atra.listener.BehaviorListener(this);
    }
    
    private void printBanner() {
        getServer().getConsoleSender().sendMessage("§b    _   _             ");
        getServer().getConsoleSender().sendMessage("§b   / \\ | |_ _ __ __ _ ");
        getServer().getConsoleSender().sendMessage("§b  / _ \\| __| '__/ _` |");
        getServer().getConsoleSender().sendMessage("§b / ___ \\ |_| | | (_| |");
        getServer().getConsoleSender().sendMessage("§b/_/   \\_\\__|_|  \\__,_|");
        getServer().getConsoleSender().sendMessage("");
        getServer().getConsoleSender().sendMessage("§b      Version: §f" + getDescription().getVersion() + " §b| Build: §f" + getBuildNumber());
        getServer().getConsoleSender().sendMessage("");
    }
    
    private void printLoader(String message) {
        getServer().getConsoleSender().sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', message));
    }
    
    private void detectVersionPlugins() {
        if (getServer().getPluginManager().getPlugin("ViaVersion") != null) {
            printLoader("§b> §fViaVersion detected");
        }
        if (getServer().getPluginManager().getPlugin("ViaBackwards") != null) {
            printLoader("§b> §fViaBackwards detected");
        }
        if (getServer().getPluginManager().getPlugin("ViaRewind") != null) {
            printLoader("§b> §fViaRewind detected");
        }
        if (getServer().getPluginManager().getPlugin("Geyser-Spigot") != null) {
            printLoader("§b> §fGeyser detected");
        }
    }
    
    private String getBuildNumber() {
        return "1.0.0"; // Build number
    }
    
    private void detectServerVersion() {
        dev.draxel.atra.util.version.ServerVersion version = dev.draxel.atra.util.version.VersionAdapter.getVersion();
        
        if (version == dev.draxel.atra.util.version.ServerVersion.UNKNOWN) {
            printLoader("§e> §fWarning: Unknown server version detected");
            printLoader("§e> §fSome features may not work correctly");
        } else {
            printLoader("§b> §fServer version: §f" + version.getVersionString());
        }
        
        if (!dev.draxel.atra.util.version.VersionAdapter.isSupported()) {
            printLoader("§c> §fThis server version may not be fully supported");
        }
    }
    
    private void printCheckSummary() {
        printLoader("§7§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        printLoader("§bRegistered Checks:");
        
        int combatChecks = checkManager.getChecksByType(dev.draxel.atra.check.CheckType.COMBAT).size();
        int movementChecks = checkManager.getChecksByType(dev.draxel.atra.check.CheckType.MOVEMENT).size();
        int packetChecks = checkManager.getChecksByType(dev.draxel.atra.check.CheckType.PACKET).size();
        int miscChecks = checkManager.getChecksByType(dev.draxel.atra.check.CheckType.MISC).size();
        
        printLoader("  §f✓ §bCombat: §f" + combatChecks + " checks");
        printLoader("  §f✓ §bMovement: §f" + movementChecks + " checks");
        printLoader("  §f✓ §bPacket: §f" + packetChecks + " checks");
        printLoader("  §f✓ §bMisc: §f" + miscChecks + " checks");
        printLoader("§7§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }
    
    private void printServerInfo() {
        printLoader("§bServer Information:");
        printLoader("  §f• §7Server Version: §f" + getServer().getVersion());
        printLoader("  §f• §7Java Version: §f" + System.getProperty("java.version"));
        printLoader("  §f• §7Online Mode: §f" + (getServer().getOnlineMode() ? "§aEnabled" : "§cDisabled"));
        printLoader("  §f• §7Max Players: §f" + getServer().getMaxPlayers());
        printLoader("§7§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }
    
    // Getters
    public static AtraAC getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public CheckManager getCheckManager() {
        return checkManager;
    }
    
    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }
    
    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }
    
    public AlertManager getAlertManager() {
        return alertManager;
    }
    
    public StorageManager getStorageManager() {
        return storageManager;
    }
    
    public dev.draxel.atra.util.update.UpdateChecker getUpdateChecker() {
        return updateChecker;
    }
}
