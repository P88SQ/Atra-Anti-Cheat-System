package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.command.CommandSender;

public class DebugCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public DebugCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        boolean currentDebug = plugin.getConfigManager().isDebugEnabled();
        
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Performance Analysis</white></gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Debug Mode:</white> " + 
            (currentDebug ? "<green>Enabled</green>" : "<red>Disabled</red>") + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Active Checks:</white> " + 
            plugin.getCheckManager().getChecks().size() + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Online Players:</white> " + 
            plugin.getServer().getOnlinePlayers().size() + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>TPS:</white> " + 
            String.format("%.2f", plugin.getServer().getTPS()[0]) + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Memory:</white> " + 
            (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024 / 1024 + "MB / " +
            Runtime.getRuntime().totalMemory() / 1024 / 1024 + "MB</gray>"));
        
        return true;
    }
    
    @Override
    public String getName() {
        return "debug";
    }
    
    @Override
    public String getPermission() {
        return "atra.debug";
    }
}
