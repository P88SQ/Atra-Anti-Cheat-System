package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.MovementPredictor;
import dev.draxel.atra.prediction.PatternAnalyzer;
import dev.draxel.atra.util.PlayerUtil;
import org.bukkit.entity.Player;

public class SpeedCheck extends Check {
    
    private static final double TOLERANCE = 0.05;
    private final MovementPredictor predictor;
    
    public SpeedCheck(AtraAC plugin) {
        super(plugin, "Speed", CheckType.MOVEMENT);
        this.predictor = new MovementPredictor();
    }
    
    public void checkSpeed(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        if (movementData.getLastLocation() == null || movementData.getCurrentLocation() == null) return;
        
        // Use advanced movement prediction
        MovementPredictor.PredictionResult prediction = predictor.predictMovement(player, movementData);
        
        if (!movementData.getSpeedHistory().isEmpty()) {
            double currentSpeed = movementData.getSpeedHistory().getLast();
            
            // Check against predicted speed
            if (!prediction.isPossible && movementData.getGroundTicks() > 3) {
                double excess = currentSpeed - prediction.maxSpeed;
                if (excess > TOLERANCE) {
                    int violationLevel = (int) Math.max(1, excess * 100);
                    flag(player, String.format("Speed: %.3f (max: %.3f, predicted: %.3f)", 
                        currentSpeed, prediction.maxSpeed, prediction.predictedSpeed), violationLevel);
                }
            }
            
            // Pattern analysis for speed hacks
            if (movementData.getSpeedHistory().size() >= 20) {
                PatternAnalyzer.PatternResult speedPattern = PatternAnalyzer.analyzeSpeedPattern(
                    movementData.getSpeedHistory()
                );
                
                if (speedPattern.isAnomalous()) {
                    int violationLevel = (int) (speedPattern.anomalyScore * 15);
                    flag(player, "Speed pattern anomaly: " + speedPattern.reason, violationLevel);
                }
            }
        }
    }
}
