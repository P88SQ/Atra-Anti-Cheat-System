package dev.draxel.atra.check;

public enum CheckType {
    COMBAT,
    MOVEMENT,
    PACKET,
    MISC
}
