package dev.draxel.atra.config;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MessagesConfig {
    
    private final AtraAC plugin;
    private FileConfiguration messagesConfig;
    private final Map<String, String> messages;
    
    public MessagesConfig(AtraAC plugin) {
        this.plugin = plugin;
        this.messages = new HashMap<>();
        loadMessages();
    }
    
    private void loadMessages() {
        File messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
        
        // Load default messages
        messages.put("prefix", messagesConfig.getString("prefix", "<gray>[<red>Atra</red>]</gray>"));
        messages.put("no-permission", messagesConfig.getString("no-permission", "<red>Nincs jogosultságod!</red>"));
        messages.put("player-not-found", messagesConfig.getString("player-not-found", "<red>Játékos nem található!</red>"));
        messages.put("alerts-enabled", messagesConfig.getString("alerts-enabled", "<green>Alerts bekapcsolva</green>"));
        messages.put("alerts-disabled", messagesConfig.getString("alerts-disabled", "<red>Alerts kikapcsolva</red>"));
        messages.put("config-reloaded", messagesConfig.getString("config-reloaded", "<green>Config újratöltve!</green>"));
    }
    
    public String getMessage(String key) {
        return messages.getOrDefault(key, key);
    }
    
    public Component getComponent(String key) {
        return ColorUtil.translate(getMessage(key));
    }
    
    public void reload() {
        messages.clear();
        loadMessages();
    }
}
