package dev.draxel.atra.api.interfaces;

import org.bukkit.entity.Player;

import java.util.UUID;

public interface IPlayerData {
    
    UUID getUUID();
    
    Player getPlayer();
}
