package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class NoClipCheck extends Check {
    
    public NoClipCheck(AtraAC plugin) {
        super(plugin, "NoClip", CheckType.MOVEMENT);
    }
    
    public void checkNoClip(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        Location loc = player.getLocation();
        Block block = loc.getBlock();
        
        // Check if player is inside a solid block
        if (block.getType().isSolid() && !block.getType().isInteractable()) {
            flag(player, String.format("Inside solid block: %s", block.getType()), 20);
            
            // Setback
            if (movementData.getLastLocation() != null) {
                player.teleport(movementData.getLastLocation());
            }
        }
    }
}
