package dev.draxel.atra.listener;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.combat.*;
import dev.draxel.atra.data.CombatData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.PermissionUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class CombatListener implements Listener {
    
    private final AtraAC plugin;
    
    public CombatListener(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        
        Player player = (Player) event.getDamager();
        if (PermissionUtil.hasBypass(player)) return;
        
        Entity target = event.getEntity();
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        CombatData combatData = data.getCombatData();
        
        // Update combat data
        combatData.setLastTarget(target);
        combatData.setLastHitTime(System.currentTimeMillis());
        combatData.incrementHitCount();
        
        // Run checks
        ReachCheck reachCheck = (ReachCheck) plugin.getCheckManager().getCheck("reach");
        if (reachCheck != null) {
            reachCheck.checkReach(player, target);
        }
        
        KillAuraCheck killAuraCheck = (KillAuraCheck) plugin.getCheckManager().getCheck("killaura");
        if (killAuraCheck != null) {
            killAuraCheck.checkRotation(player, target, player.getLocation().getYaw(), player.getLocation().getPitch());
            killAuraCheck.checkMultiTarget(player);
        }
        
        CriticalsCheck criticalsCheck = (CriticalsCheck) plugin.getCheckManager().getCheck("criticals");
        if (criticalsCheck != null) {
            criticalsCheck.checkCritical(player, event.isCritical());
        }
        
        AimAssistCheck aimAssistCheck = (AimAssistCheck) plugin.getCheckManager().getCheck("aimassist");
        if (aimAssistCheck != null) {
            aimAssistCheck.checkAim(player);
        }
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (PermissionUtil.hasBypass(player)) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        
        // Track clicks for AutoClicker check
        AutoClickerCheck autoClickerCheck = (AutoClickerCheck) plugin.getCheckManager().getCheck("autoclicker");
        if (autoClickerCheck != null) {
            autoClickerCheck.checkClick(player);
        }
    }
}
