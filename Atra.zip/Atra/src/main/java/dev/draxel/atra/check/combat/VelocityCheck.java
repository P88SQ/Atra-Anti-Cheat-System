package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class VelocityCheck extends Check {
    
    private static final double MIN_VELOCITY_PERCENT = 0.20;
    private static final double TOLERANCE = 0.15;
    
    public VelocityCheck(AtraAC plugin) {
        super(plugin, "Velocity", CheckType.COMBAT);
    }
    
    public void checkVelocity(Player player, Vector expectedVelocity) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        // Wait a few ticks to check actual movement
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (movementData.getLastVelocity() == null) return;
            
            Vector actualVelocity = movementData.getLastVelocity();
            
            double expectedHorizontal = Math.sqrt(
                expectedVelocity.getX() * expectedVelocity.getX() + 
                expectedVelocity.getZ() * expectedVelocity.getZ()
            );
            
            double actualHorizontal = Math.sqrt(
                actualVelocity.getX() * actualVelocity.getX() + 
                actualVelocity.getZ() * actualVelocity.getZ()
            );
            
            double percent = actualHorizontal / expectedHorizontal;
            
            if (percent < MIN_VELOCITY_PERCENT - TOLERANCE) {
                flag(player, String.format("Low velocity: %.0f%% of expected", percent * 100), 10);
            }
        }, 3L);
    }
}
