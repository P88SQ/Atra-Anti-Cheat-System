package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.ClickData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.PatternAnalyzer;
import dev.draxel.atra.util.MathUtil;
import org.bukkit.entity.Player;

public class AutoClickerCheck extends Check {
    
    private static final int MAX_HUMAN_CPS = 20;
    private static final double MIN_STD_DEVIATION = 10.0;
    
    public AutoClickerCheck(AtraAC plugin) {
        super(plugin, "AutoClicker", CheckType.COMBAT);
    }
    
    public void checkClick(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        ClickData clickData = data.getClickData();
        
        clickData.addClick();
        
        int cps = clickData.getCPS();
        
        // Check CPS
        if (cps > MAX_HUMAN_CPS) {
            flag(player, String.format("High CPS: %d", cps), 5);
        }
        
        // Advanced click pattern analysis
        if (clickData.getClickDelays().size() >= 20) {
            PatternAnalyzer.PatternResult clickPattern = PatternAnalyzer.analyzeClickPattern(clickData.getClickDelays());
            
            if (clickPattern.isAnomalous()) {
                int violationLevel = (int) (clickPattern.anomalyScore * 20);
                flag(player, "Click pattern anomaly: " + clickPattern.reason, violationLevel);
            }
            
            // Traditional standard deviation check as backup
            double stdDev = MathUtil.getStandardDeviation(clickData.getClickDelays());
            
            if (stdDev < MIN_STD_DEVIATION && cps > 10 && !clickPattern.isAnomalous()) {
                flag(player, String.format("Robotic click pattern (StdDev: %.2f)", stdDev), 8);
            }
            
            // Check for double-click patterns (common in some auto-clickers)
            int doubleClickCount = 0;
            Long[] delays = clickData.getClickDelays().toArray(new Long[0]);
            for (int i = 0; i < delays.length - 1; i++) {
                if (delays[i] < 10 && delays[i + 1] > 50) {
                    doubleClickCount++;
                }
            }
            
            double doubleClickRatio = (double) doubleClickCount / delays.length;
            if (doubleClickRatio > 0.3) {
                flag(player, String.format("Double-click pattern detected (%.1f%%)", doubleClickRatio * 100), 8);
            }
        }
    }
}
