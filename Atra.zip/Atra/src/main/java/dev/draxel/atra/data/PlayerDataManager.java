package dev.draxel.atra.data;

import dev.draxel.atra.AtraAC;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {
    
    private final AtraAC plugin;
    private final Map<UUID, PlayerData> playerDataMap;
    
    public PlayerDataManager(AtraAC plugin) {
        this.plugin = plugin;
        this.playerDataMap = new HashMap<>();
    }
    
    public PlayerData getPlayerData(Player player) {
        return playerDataMap.computeIfAbsent(player.getUniqueId(), k -> new PlayerData(player));
    }
    
    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.get(uuid);
    }
    
    public void removePlayerData(UUID uuid) {
        playerDataMap.remove(uuid);
    }
    
    public void cleanup() {
        playerDataMap.clear();
    }
    
    public Map<UUID, PlayerData> getAllPlayerData() {
        return playerDataMap;
    }
}
