package dev.draxel.atra.util;

public class TickUtil {
    
    private static final long TICK_TIME = 50L; // 50ms per tick
    
    public static long getCurrentTick() {
        return System.currentTimeMillis() / TICK_TIME;
    }
    
    public static long millisToTicks(long millis) {
        return millis / TICK_TIME;
    }
    
    public static long ticksToMillis(long ticks) {
        return ticks * TICK_TIME;
    }
}
