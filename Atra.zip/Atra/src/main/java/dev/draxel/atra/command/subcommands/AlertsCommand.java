package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AlertsCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public AlertsCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Csak játékosok használhatják!");
            return true;
        }
        
        Player player = (Player) sender;
        plugin.getAlertManager().toggleAlerts(player);
        
        return true;
    }
    
    @Override
    public String getName() {
        return "alerts";
    }
    
    @Override
    public String getPermission() {
        return "atra.alerts";
    }
}
