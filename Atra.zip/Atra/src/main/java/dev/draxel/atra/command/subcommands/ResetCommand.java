package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.api.AtraAPI;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ResetCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public ResetCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.translate("<red>Használat: /atra reset <játékos> [check]</red>"));
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ColorUtil.translate("<red>Játékos nem található!</red>"));
            return true;
        }
        
        if (args.length >= 3) {
            AtraAPI.resetViolations(target, args[2]);
            sender.sendMessage(ColorUtil.translate(
                "<blue>Atra <gray>| <white>Reset violations for " + target.getName() + " (" + args[2] + ")</white></gray>"
            ));
        } else {
            AtraAPI.resetAllViolations(target);
            sender.sendMessage(ColorUtil.translate(
                "<blue>Atra <gray>| <white>Reset all violations for " + target.getName() + "</white></gray>"
            ));
        }
        
        return true;
    }
    
    @Override
    public String getName() {
        return "reset";
    }
    
    @Override
    public String getPermission() {
        return "atra.reset";
    }
}
