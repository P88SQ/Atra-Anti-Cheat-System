package dev.draxel.atra.prediction;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.*;

public class VelocityTracker {
    
    private final Map<UUID, List<VelocityEntry>> velocityMap;
    
    public VelocityTracker() {
        this.velocityMap = new HashMap<>();
    }
    
    public void addVelocity(Player player, Vector velocity, String source) {
        UUID uuid = player.getUniqueId();
        velocityMap.computeIfAbsent(uuid, k -> new ArrayList<>());
        
        List<VelocityEntry> entries = velocityMap.get(uuid);
        entries.add(new VelocityEntry(velocity, source, System.currentTimeMillis()));
        
        // Keep only last 20 entries
        if (entries.size() > 20) {
            entries.remove(0);
        }
    }
    
    public Vector getExpectedVelocity(Player player) {
        UUID uuid = player.getUniqueId();
        List<VelocityEntry> entries = velocityMap.get(uuid);
        
        if (entries == null || entries.isEmpty()) {
            return new Vector(0, 0, 0);
        }
        
        // Get most recent velocity
        VelocityEntry latest = entries.get(entries.size() - 1);
        
        // Check if it's still valid (within 1 second)
        if (System.currentTimeMillis() - latest.timestamp > 1000) {
            return new Vector(0, 0, 0);
        }
        
        return latest.velocity;
    }
    
    public void clearVelocity(Player player) {
        velocityMap.remove(player.getUniqueId());
    }
    
    private static class VelocityEntry {
        final Vector velocity;
        final String source;
        final long timestamp;
        
        VelocityEntry(Vector velocity, String source, long timestamp) {
            this.velocity = velocity;
            this.source = source;
            this.timestamp = timestamp;
        }
    }
}
