package dev.draxel.atra.config;

import dev.draxel.atra.AtraAC;

public class SettingsConfig {
    
    private final AtraAC plugin;
    
    public SettingsConfig(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public boolean isDebugEnabled() {
        return plugin.getConfig().getBoolean("debug", false);
    }
    
    public int getViolationDecayRate() {
        return plugin.getConfig().getInt("violations.decay-rate", 1);
    }
    
    public int getViolationDecayInterval() {
        return plugin.getConfig().getInt("violations.decay-interval", 2);
    }
    
    public int getSetbackThreshold() {
        return plugin.getConfig().getInt("punishments.setback-threshold", 20);
    }
    
    public int getKickThreshold() {
        return plugin.getConfig().getInt("punishments.kick-threshold", 50);
    }
    
    public int getBanThreshold() {
        return plugin.getConfig().getInt("punishments.ban-threshold", 100);
    }
    
    public int getBanDurationDays() {
        return plugin.getConfig().getInt("punishments.ban-duration-days", 7);
    }
    
    public boolean isPingCompensationEnabled() {
        return plugin.getConfig().getBoolean("ping-compensation.enabled", true);
    }
    
    public int getMaxPingCompensation() {
        return plugin.getConfig().getInt("ping-compensation.max-compensation", 300);
    }
}
