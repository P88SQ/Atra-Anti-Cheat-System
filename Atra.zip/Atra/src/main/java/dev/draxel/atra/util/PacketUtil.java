package dev.draxel.atra.util;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import org.bukkit.entity.Player;

public class PacketUtil {
    
    public static boolean isMovementPacket(PacketType type) {
        return type == PacketType.Play.Client.POSITION ||
               type == PacketType.Play.Client.POSITION_LOOK ||
               type == PacketType.Play.Client.LOOK ||
               type == PacketType.Play.Client.FLYING;
    }
    
    public static boolean isActionPacket(PacketType type) {
        return type == PacketType.Play.Client.USE_ENTITY ||
               type == PacketType.Play.Client.ARM_ANIMATION ||
               type == PacketType.Play.Client.BLOCK_DIG ||
               type == PacketType.Play.Client.BLOCK_PLACE;
    }
}
