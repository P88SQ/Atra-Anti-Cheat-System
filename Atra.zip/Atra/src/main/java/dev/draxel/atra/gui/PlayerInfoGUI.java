package dev.draxel.atra.gui;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.data.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PlayerInfoGUI implements MenuManager.GUI {
    
    private final AtraAC plugin;
    private final Player target;
    
    public PlayerInfoGUI(AtraAC plugin, Player target) {
        this.plugin = plugin;
        this.target = target;
    }
    
    @Override
    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, 
            Component.text("Atra - " + target.getName()));
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        
        // Player head
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta headMeta = head.getItemMeta();
        headMeta.displayName(Component.text(target.getName()));
        head.setItemMeta(headMeta);
        inv.setItem(13, head);
        
        player.openInventory(inv);
    }
}
