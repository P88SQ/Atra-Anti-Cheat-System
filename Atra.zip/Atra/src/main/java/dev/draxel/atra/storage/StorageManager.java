package dev.draxel.atra.storage;

import dev.draxel.atra.AtraAC;
import org.bukkit.entity.Player;

public class StorageManager {
    
    private final AtraAC plugin;
    
    public StorageManager(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public void savePlayerData(Player player) {
        // TODO: Implement data saving
    }
    
    public void saveAll() {
        // TODO: Implement save all
    }
    
    public void loadPlayerData(Player player) {
        // TODO: Implement data loading
    }
}
