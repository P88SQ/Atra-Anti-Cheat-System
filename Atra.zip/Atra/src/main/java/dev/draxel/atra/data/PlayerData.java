package dev.draxel.atra.data;

import dev.draxel.atra.api.interfaces.IPlayerData;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerData implements IPlayerData {
    
    private final UUID uuid;
    private final Player player;
    
    private final CombatData combatData;
    private final MovementData movementData;
    private final ClickData clickData;
    private final Map<String, ViolationData> violations;
    
    private long lastPacketTime;
    private int packetCount;
    private long lastAlertTime;
    
    public PlayerData(Player player) {
        this.uuid = player.getUniqueId();
        this.player = player;
        
        this.combatData = new CombatData();
        this.movementData = new MovementData();
        this.clickData = new ClickData();
        this.violations = new HashMap<>();
        
        this.lastPacketTime = System.currentTimeMillis();
        this.packetCount = 0;
        this.lastAlertTime = 0;
    }
    
    @Override
    public UUID getUUID() {
        return uuid;
    }
    
    @Override
    public Player getPlayer() {
        return player;
    }
    
    public CombatData getCombatData() {
        return combatData;
    }
    
    public MovementData getMovementData() {
        return movementData;
    }
    
    public ClickData getClickData() {
        return clickData;
    }
    
    public ViolationData getViolationData(String checkName) {
        return violations.computeIfAbsent(checkName, k -> new ViolationData(checkName));
    }
    
    public Map<String, ViolationData> getAllViolations() {
        return violations;
    }
    
    public void resetViolations(String checkName) {
        violations.remove(checkName);
    }
    
    public void resetAllViolations() {
        violations.clear();
    }
    
    public void incrementPacketCount() {
        packetCount++;
        lastPacketTime = System.currentTimeMillis();
    }
    
    public int getPacketCount() {
        return packetCount;
    }
    
    public void resetPacketCount() {
        packetCount = 0;
    }
    
    public long getLastPacketTime() {
        return lastPacketTime;
    }
    
    public long getLastAlertTime() {
        return lastAlertTime;
    }
    
    public void setLastAlertTime(long time) {
        this.lastAlertTime = time;
    }
}
