package dev.draxel.atra.storage;

import dev.draxel.atra.AtraAC;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogStorage {
    
    private final AtraAC plugin;
    private final File logsFolder;
    private final SimpleDateFormat dateFormat;
    
    public LogStorage(AtraAC plugin) {
        this.plugin = plugin;
        this.logsFolder = new File(plugin.getDataFolder(), "logs");
        this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        if (!logsFolder.exists()) {
            logsFolder.mkdirs();
        }
    }
    
    public void logViolation(String playerName, String checkName, String info, int violations) {
        String timestamp = dateFormat.format(new Date());
        String logEntry = String.format("[%s] %s failed %s (%s) VL: %d\n", 
            timestamp, playerName, checkName, info, violations);
        
        writeToLog(logEntry);
    }
    
    private void writeToLog(String entry) {
        SimpleDateFormat fileFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fileName = "violations-" + fileFormat.format(new Date()) + ".log";
        File logFile = new File(logsFolder, fileName);
        
        try (FileWriter writer = new FileWriter(logFile, true)) {
            writer.write(entry);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to write to log file!");
            e.printStackTrace();
        }
    }
}
