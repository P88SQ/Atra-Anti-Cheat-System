package dev.draxel.atra.util;

import org.bukkit.Location;
import org.bukkit.util.Vector;

public class LocationUtil {
    
    public static double getDistance(Location from, Location to) {
        return from.distance(to);
    }
    
    public static double getHorizontalDistance(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    public static double getVerticalDistance(Location from, Location to) {
        return Math.abs(to.getY() - from.getY());
    }
    
    public static Vector getDirection(Location from, Location to) {
        return to.toVector().subtract(from.toVector()).normalize();
    }
    
    public static double getYawDifference(float yaw1, float yaw2) {
        float diff = Math.abs(yaw1 - yaw2) % 360;
        return diff > 180 ? 360 - diff : diff;
    }
    
    public static double getPitchDifference(float pitch1, float pitch2) {
        return Math.abs(pitch1 - pitch2);
    }
}
