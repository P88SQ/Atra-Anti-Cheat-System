package dev.draxel.atra.util;

import dev.draxel.atra.util.version.VersionAdapter;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

public class PlayerUtil {
    
    public static int getPing(Player player) {
        return VersionAdapter.getPing(player);
    }
    
    public static double getBaseSpeed(Player player) {
        double speed = 0.1;
        
        if (player.isSprinting()) {
            speed = 0.13;
        }
        
        // Speed effect
        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            int amplifier = player.getPotionEffect(PotionEffectType.SPEED).getAmplifier();
            speed *= 1.0 + (0.2 * (amplifier + 1));
        }
        
        // Slowness effect
        if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
            int amplifier = player.getPotionEffect(PotionEffectType.SLOWNESS).getAmplifier();
            speed *= 1.0 - (0.15 * (amplifier + 1));
        }
        
        return speed;
    }
    
    public static double getJumpHeight(Player player) {
        double height = 1.25;
        
        if (player.hasPotionEffect(PotionEffectType.JUMP_BOOST)) {
            int amplifier = player.getPotionEffect(PotionEffectType.JUMP_BOOST).getAmplifier();
            height += 0.5 * (amplifier + 1);
        }
        
        return height;
    }
    
    public static boolean isOnGround(Player player) {
        return player.isOnGround();
    }
    
    public static boolean hasLineOfSight(Player player, org.bukkit.entity.Entity target) {
        return player.hasLineOfSight(target);
    }
    
    public static boolean isSwimming(Player player) {
        return VersionAdapter.isSwimming(player);
    }
    
    public static boolean isRiptiding(Player player) {
        return VersionAdapter.isRiptiding(player);
    }
    
    public static boolean hasSlowFalling(Player player) {
        return VersionAdapter.hasSlowFalling(player);
    }
    
    public static boolean hasLevitation(Player player) {
        return VersionAdapter.hasLevitation(player);
    }
    
    public static float getAttackCooldown(Player player) {
        return VersionAdapter.getAttackCooldown(player);
    }
}
