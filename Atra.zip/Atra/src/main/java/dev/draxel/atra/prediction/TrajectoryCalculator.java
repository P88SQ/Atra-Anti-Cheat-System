package dev.draxel.atra.prediction;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Advanced trajectory calculation for projectiles and entity movement
 */
public class TrajectoryCalculator {
    
    private static final double GRAVITY = 0.08;
    private static final double DRAG = 0.99;
    
    /**
     * Calculate if a player can hit an entity given their rotation
     */
    public static HitPrediction predictHit(Player player, Entity target, double maxReach) {
        Location eyeLocation = player.getEyeLocation();
        Vector direction = eyeLocation.getDirection();
        
        // Ray-trace from eye to max reach
        Location targetLocation = target.getLocation().add(0, target.getHeight() / 2, 0);
        
        // Calculate closest point on ray to target
        Vector toTarget = targetLocation.toVector().subtract(eyeLocation.toVector());
        double projectionLength = toTarget.dot(direction);
        
        // Clamp to max reach
        projectionLength = Math.max(0, Math.min(projectionLength, maxReach));
        
        // Calculate closest point
        Vector closestPoint = eyeLocation.toVector().add(direction.clone().multiply(projectionLength));
        double distance = closestPoint.distance(targetLocation.toVector());
        
        // Check if within hitbox (0.3 blocks radius + tolerance)
        double hitboxRadius = 0.3 + (player.getPing() / 1000.0) * 0.3;
        boolean canHit = distance <= hitboxRadius;
        
        return new HitPrediction(canHit, distance, projectionLength);
    }
    
    /**
     * Predict entity position N ticks in the future
     */
    public static Location predictEntityPosition(Entity entity, int ticks) {
        Location current = entity.getLocation();
        Vector velocity = entity.getVelocity();
        
        for (int i = 0; i < ticks; i++) {
            // Apply gravity
            velocity.setY(velocity.getY() - GRAVITY);
            
            // Apply drag
            velocity.multiply(DRAG);
            
            // Update position
            current.add(velocity);
        }
        
        return current;
    }
    
    /**
     * Calculate optimal aim point for moving target
     */
    public static Vector calculateLeadAim(Location shooter, Entity target, double projectileSpeed) {
        Location targetLoc = target.getLocation();
        Vector targetVelocity = target.getVelocity();
        
        // Calculate time to impact
        double distance = shooter.distance(targetLoc);
        double timeToImpact = distance / projectileSpeed;
        
        // Predict target position at impact
        Vector predictedOffset = targetVelocity.clone().multiply(timeToImpact);
        Location predictedTarget = targetLoc.clone().add(predictedOffset);
        
        // Calculate aim direction
        return predictedTarget.toVector().subtract(shooter.toVector()).normalize();
    }
    
    /**
     * Check if rotation is humanly possible
     */
    public static boolean isRotationHumanlyPossible(double yawChange, double pitchChange, int ping) {
        // Maximum human rotation per tick (with ping compensation)
        double maxRotation = 180.0 + (ping / 10.0);
        
        double totalRotation = Math.sqrt(yawChange * yawChange + pitchChange * pitchChange);
        
        return totalRotation <= maxRotation;
    }
    
    /**
     * Calculate rotation needed to look at target
     */
    public static RotationResult calculateRotation(Location from, Location to) {
        Vector direction = to.toVector().subtract(from.toVector());
        
        // Calculate yaw
        double yaw = Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ()));
        
        // Calculate pitch
        double horizontalDistance = Math.sqrt(
                direction.getX() * direction.getX() + 
                direction.getZ() * direction.getZ()
        );
        double pitch = Math.toDegrees(Math.atan(-direction.getY() / horizontalDistance));
        
        return new RotationResult((float) yaw, (float) pitch);
    }
    
    /**
     * Check if player is looking at entity within tolerance
     */
    public static boolean isLookingAt(Player player, Entity target, double tolerance) {
        RotationResult needed = calculateRotation(player.getEyeLocation(), target.getLocation());
        
        float currentYaw = player.getLocation().getYaw();
        float currentPitch = player.getLocation().getPitch();
        
        double yawDiff = Math.abs(normalizeYaw(currentYaw - needed.yaw));
        double pitchDiff = Math.abs(currentPitch - needed.pitch);
        
        return yawDiff <= tolerance && pitchDiff <= tolerance;
    }
    
    /**
     * Normalize yaw to -180 to 180 range
     */
    private static float normalizeYaw(float yaw) {
        yaw = yaw % 360;
        if (yaw > 180) yaw -= 360;
        if (yaw < -180) yaw += 360;
        return yaw;
    }
    
    // Result classes
    public static class HitPrediction {
        public final boolean canHit;
        public final double distance;
        public final double reach;
        
        public HitPrediction(boolean canHit, double distance, double reach) {
            this.canHit = canHit;
            this.distance = distance;
            this.reach = reach;
        }
    }
    
    public static class RotationResult {
        public final float yaw;
        public final float pitch;
        
        public RotationResult(float yaw, float pitch) {
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }
    
    public static class PatternResult {
        public final double anomalyScore;
        public final String reason;
        
        public PatternResult(double anomalyScore, String reason) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
        }
        
        public boolean isAnomalous() {
            return anomalyScore > 0.5;
        }
    }
}
