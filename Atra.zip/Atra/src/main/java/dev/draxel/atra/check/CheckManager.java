package dev.draxel.atra.check;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.combat.*;
import dev.draxel.atra.check.misc.*;
import dev.draxel.atra.check.movement.*;
import dev.draxel.atra.check.packet.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckManager {
    
    private final AtraAC plugin;
    private final Map<String, Check> checks;
    
    public CheckManager(AtraAC plugin) {
        this.plugin = plugin;
        this.checks = new HashMap<>();
    }
    
    public void registerChecks() {
        // Combat checks
        registerCheck(new ReachCheck(plugin));
        registerCheck(new KillAuraCheck(plugin));
        registerCheck(new AutoClickerCheck(plugin));
        registerCheck(new VelocityCheck(plugin));
        registerCheck(new CriticalsCheck(plugin));
        registerCheck(new AimAssistCheck(plugin));
        
        // Movement checks
        registerCheck(new FlyCheck(plugin));
        registerCheck(new SpeedCheck(plugin));
        registerCheck(new NoClipCheck(plugin));
        registerCheck(new StepCheck(plugin));
        registerCheck(new JesusCheck(plugin));
        registerCheck(new ElytraCheck(plugin));
        
        // Packet checks
        registerCheck(new TimerCheck(plugin));
        registerCheck(new BadPacketsCheck(plugin));
        registerCheck(new PingSpooferCheck(plugin));
        registerCheck(new InvalidMotionCheck(plugin));
        
        // Misc checks
        registerCheck(new ScaffoldCheck(plugin));
        registerCheck(new FastBreakCheck(plugin));
        registerCheck(new InventoryCheck(plugin));
        registerCheck(new AutoToolCheck(plugin));
    }
    
    private void registerCheck(Check check) {
        checks.put(check.getName().toLowerCase(), check);
    }
    
    public Check getCheck(String name) {
        return checks.get(name.toLowerCase());
    }
    
    public List<Check> getChecks() {
        return new ArrayList<>(checks.values());
    }
    
    public List<Check> getChecksByType(CheckType type) {
        List<Check> result = new ArrayList<>();
        for (Check check : checks.values()) {
            if (check.getType() == type) {
                result.add(check);
            }
        }
        return result;
    }
}
