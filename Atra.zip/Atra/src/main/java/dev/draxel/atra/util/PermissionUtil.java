package dev.draxel.atra.util;

import org.bukkit.entity.Player;

public class PermissionUtil {
    
    public static boolean hasPermission(Player player, String permission) {
        return player.hasPermission(permission);
    }
    
    public static boolean hasBypass(Player player) {
        return player.hasPermission("atra.bypass");
    }
    
    public static boolean canSeeAlerts(Player player) {
        return player.hasPermission("atra.alerts");
    }
    
    public static boolean isAdmin(Player player) {
        return player.hasPermission("atra.admin");
    }
}
