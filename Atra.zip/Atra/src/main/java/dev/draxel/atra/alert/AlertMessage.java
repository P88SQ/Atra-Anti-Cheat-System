package dev.draxel.atra.alert;

import dev.draxel.atra.check.Check;
import dev.draxel.atra.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

public class AlertMessage {
    
    public static Component format(Player player, Check check, String information, int violations) {
        return ColorUtil.translate(
            String.format(
                "<gray>[<red>Atra</red>]</gray> <white>%s</white> <gray>failed</gray> <yellow>%s</yellow> <gray>(%s) <red>VL: %d</red></gray>",
                player.getName(),
                check.getName(),
                information,
                violations
            )
        );
    }
    
    public static Component formatDetailed(Player player, Check check, String information, int violations) {
        return ColorUtil.translate(
            String.format(
                "<gray>[<red>Atra</red>]</gray>\n" +
                "<white>Játékos:</white> <yellow>%s</yellow>\n" +
                "<white>Check:</white> <yellow>%s</yellow> <gray>(%s)</gray>\n" +
                "<white>Info:</white> <gray>%s</gray>\n" +
                "<white>VL:</white> <red>%d</red>\n" +
                "<white>Ping:</white> <gray>%dms</gray>",
                player.getName(),
                check.getName(),
                check.getType(),
                information,
                violations,
                player.getPing()
            )
        );
    }
}
