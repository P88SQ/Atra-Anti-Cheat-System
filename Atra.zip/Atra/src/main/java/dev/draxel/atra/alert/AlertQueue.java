package dev.draxel.atra.alert;

import org.bukkit.entity.Player;

import java.util.*;

public class AlertQueue {
    
    private final Map<UUID, Queue<AlertEntry>> alertQueues;
    private static final int MAX_QUEUE_SIZE = 5;
    private static final long SPAM_THRESHOLD = 500; // 500ms
    
    public AlertQueue() {
        this.alertQueues = new HashMap<>();
    }
    
    public boolean shouldSendAlert(Player player, String checkName) {
        UUID uuid = player.getUniqueId();
        Queue<AlertEntry> queue = alertQueues.computeIfAbsent(uuid, k -> new LinkedList<>());
        
        long currentTime = System.currentTimeMillis();
        
        // Remove old entries
        queue.removeIf(entry -> currentTime - entry.timestamp > 5000);
        
        // Check for spam
        long recentAlerts = queue.stream()
            .filter(entry -> entry.checkName.equals(checkName))
            .filter(entry -> currentTime - entry.timestamp < SPAM_THRESHOLD)
            .count();
        
        if (recentAlerts >= 3) {
            return false; // Too many alerts in short time
        }
        
        // Add to queue
        queue.add(new AlertEntry(checkName, currentTime));
        
        // Limit queue size
        while (queue.size() > MAX_QUEUE_SIZE) {
            queue.poll();
        }
        
        return true;
    }
    
    public void clearQueue(Player player) {
        alertQueues.remove(player.getUniqueId());
    }
    
    private static class AlertEntry {
        final String checkName;
        final long timestamp;
        
        AlertEntry(String checkName, long timestamp) {
            this.checkName = checkName;
            this.timestamp = timestamp;
        }
    }
}
