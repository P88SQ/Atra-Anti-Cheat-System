package dev.draxel.atra.alert;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.ColorUtil;
import dev.draxel.atra.util.PermissionUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AlertManager {
    
    private final AtraAC plugin;
    private final Set<UUID> alertsEnabled;
    private static final long ALERT_COOLDOWN = 1000; // 1 second
    
    public AlertManager(AtraAC plugin) {
        this.plugin = plugin;
        this.alertsEnabled = new HashSet<>();
    }
    
    public void sendAlert(Player player, Check check, String information, int violations) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        
        // Check cooldown
        long currentTime = System.currentTimeMillis();
        if (currentTime - data.getLastAlertTime() < ALERT_COOLDOWN) {
            return;
        }
        
        data.setLastAlertTime(currentTime);
        
        Component message = ColorUtil.translate(
            String.format("<blue>Atra <gray>| <white>%s</white> failed <yellow>%s</yellow> (%s) <red>VL: %d</red></gray>",
                player.getName(),
                check.getName(),
                information,
                violations)
        );
        
        // Send to all staff with alerts enabled
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (hasAlertsEnabled(staff) && PermissionUtil.canSeeAlerts(staff)) {
                staff.sendMessage(message);
            }
        }
    }
    
    public void enableAlerts(Player player) {
        alertsEnabled.add(player.getUniqueId());
    }
    
    public void disableAlerts(Player player) {
        alertsEnabled.remove(player.getUniqueId());
    }
    
    public boolean hasAlertsEnabled(Player player) {
        return alertsEnabled.contains(player.getUniqueId());
    }
    
    public void toggleAlerts(Player player) {
        if (hasAlertsEnabled(player)) {
            disableAlerts(player);
            player.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Alerts disabled</white></gray>"));
        } else {
            enableAlerts(player);
            player.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Alerts enabled</white></gray>"));
        }
    }
}
