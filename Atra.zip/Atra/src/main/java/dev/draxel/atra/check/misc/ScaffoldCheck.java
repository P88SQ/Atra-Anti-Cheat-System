package dev.draxel.atra.check.misc;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public class ScaffoldCheck extends Check {
    
    private static final double MIN_ROTATION_CHANGE = 5.0;
    
    public ScaffoldCheck(AtraAC plugin) {
        super(plugin, "Scaffold", CheckType.MISC);
    }
    
    public void checkScaffold(Player player, Block placedBlock) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        // Check if placing blocks while moving fast
        if (!movementData.getSpeedHistory().isEmpty()) {
            double speed = movementData.getSpeedHistory().getLast();
            
            if (speed > 0.2 && player.getLocation().getPitch() > 70) {
                flag(player, "Fast scaffold detected", 5);
            }
        }
    }
}
