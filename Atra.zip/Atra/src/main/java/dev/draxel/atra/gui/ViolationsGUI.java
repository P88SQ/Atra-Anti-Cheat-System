package dev.draxel.atra.gui;

import dev.draxel.atra.AtraAC;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class ViolationsGUI implements MenuManager.GUI {
    
    private final AtraAC plugin;
    private final Player target;
    
    public ViolationsGUI(AtraAC plugin, Player target) {
        this.plugin = plugin;
        this.target = target;
    }
    
    @Override
    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, 
            Component.text("Violations - " + target.getName()));
        
        // TODO: Add violation items
        
        player.openInventory(inv);
    }
}
