package dev.draxel.atra.check.packet;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.entity.Player;

public class PingSpooferCheck extends Check {
    
    public PingSpooferCheck(AtraAC plugin) {
        super(plugin, "PingSpoofer", CheckType.PACKET);
    }
    
    public void checkPing(Player player, int reportedPing) {
        if (!enabled) return;
        
        int actualPing = player.getPing();
        
        if (Math.abs(actualPing - reportedPing) > 100) {
            flag(player, String.format("Ping mismatch: %d vs %d", actualPing, reportedPing), 5);
        }
    }
}
