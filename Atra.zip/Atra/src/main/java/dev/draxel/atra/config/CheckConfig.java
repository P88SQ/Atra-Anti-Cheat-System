package dev.draxel.atra.config;

import dev.draxel.atra.AtraAC;
import org.bukkit.configuration.ConfigurationSection;

public class CheckConfig {
    
    private final AtraAC plugin;
    
    public CheckConfig(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public boolean isCheckEnabled(String checkName) {
        return plugin.getConfig().getBoolean("checks." + checkName.toLowerCase() + ".enabled", true);
    }
    
    public int getMaxViolations(String checkName) {
        return plugin.getConfig().getInt("checks." + checkName.toLowerCase() + ".max-violations", 50);
    }
    
    public double getDouble(String checkName, String key, double defaultValue) {
        return plugin.getConfig().getDouble("checks." + checkName.toLowerCase() + "." + key, defaultValue);
    }
    
    public int getInt(String checkName, String key, int defaultValue) {
        return plugin.getConfig().getInt("checks." + checkName.toLowerCase() + "." + key, defaultValue);
    }
    
    public String getString(String checkName, String key, String defaultValue) {
        return plugin.getConfig().getString("checks." + checkName.toLowerCase() + "." + key, defaultValue);
    }
    
    public ConfigurationSection getCheckSection(String checkName) {
        return plugin.getConfig().getConfigurationSection("checks." + checkName.toLowerCase());
    }
}
