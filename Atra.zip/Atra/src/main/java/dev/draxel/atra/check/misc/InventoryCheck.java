package dev.draxel.atra.check.misc;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class InventoryCheck extends Check {
    
    private final Map<UUID, Long> lastInventoryAction;
    
    public InventoryCheck(AtraAC plugin) {
        super(plugin, "Inventory", CheckType.MISC);
        this.lastInventoryAction = new HashMap<>();
    }
    
    public void checkInventoryAction(Player player) {
        if (!enabled) return;
        
        long currentTime = System.currentTimeMillis();
        long lastTime = lastInventoryAction.getOrDefault(player.getUniqueId(), 0L);
        long timeDiff = currentTime - lastTime;
        
        // Check for impossible inventory actions (too fast)
        if (timeDiff < 50) {
            flag(player, String.format("Fast inventory action: %dms", timeDiff), 5);
        }
        
        lastInventoryAction.put(player.getUniqueId(), currentTime);
    }
}
