package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.MovementPredictor;
import dev.draxel.atra.prediction.PhysicsEngine;
import org.bukkit.entity.Player;

public class FlyCheck extends Check {
    
    private static final double GRAVITY = 0.08;
    private static final int MAX_AIR_TICKS = 100;
    private final MovementPredictor predictor;
    
    public FlyCheck(AtraAC plugin) {
        super(plugin, "Fly", CheckType.MOVEMENT);
        this.predictor = new MovementPredictor();
    }
    
    public void checkFly(Player player) {
        if (!enabled) return;
        if (player.getAllowFlight() || player.isGliding()) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        if (movementData.getAirTicks() > MAX_AIR_TICKS) {
            flag(player, String.format("Too long in air: %d ticks", movementData.getAirTicks()), 5);
        }
        
        // Use physics engine to validate movement
        if (movementData.getLastVelocity() != null && player.getVelocity() != null) {
            PhysicsEngine.PhysicsResult physicsResult = PhysicsEngine.simulateMovement(
                player,
                player.getVelocity(),
                movementData.getLastVelocity(),
                movementData.isOnGround()
            );
            
            if (!physicsResult.isValid && movementData.getAirTicks() > 5) {
                int violationLevel = (int) Math.max(5, physicsResult.deviation * 50);
                flag(player, String.format("Invalid physics (deviation: %.3f)", physicsResult.deviation), violationLevel);
            }
        }
        
        // Check for no gravity with advanced prediction
        if (movementData.getAirTicks() > 5 && movementData.getLastVelocity() != null) {
            double yVelocity = movementData.getLastVelocity().getY();
            
            MovementPredictor.PredictionResult prediction = predictor.predictMovement(player, movementData);
            
            if (Math.abs(yVelocity) < 0.01 && !player.isInWater() && !prediction.isPossible) {
                flag(player, "No gravity detected", 12);
            }
        }
    }
}
