package dev.draxel.atra.prediction;

import dev.draxel.atra.util.MathUtil;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Advanced pattern analysis for detecting anomalies in player behavior
 */
public class PatternAnalyzer {
    
    /**
     * Analyze movement pattern for anomalies
     */
    public static PatternResult analyzeMovementPattern(Deque<Vector> velocityHistory) {
        if (velocityHistory.size() < 10) {
            return new PatternResult(0.0, "Insufficient data");
        }
        
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        // Convert to list for easier analysis
        List<Vector> velocities = velocityHistory.stream()
                .collect(Collectors.toList());
        
        // 1. Check for unnatural consistency (bot-like movement)
        double consistency = calculateConsistency(velocities);
        if (consistency > 0.95) {
            anomalyScore += 0.3;
            reasons.append("Unnatural consistency; ");
        }
        
        // 2. Check for impossible acceleration
        double maxAcceleration = calculateMaxAcceleration(velocities);
        if (maxAcceleration > 2.0) {
            anomalyScore += 0.4;
            reasons.append("Impossible acceleration; ");
        }
        
        // 3. Check for teleport-like movements
        if (hasTeleportPattern(velocities)) {
            anomalyScore += 0.5;
            reasons.append("Teleport pattern; ");
        }
        
        // 4. Check for oscillation (speed hack pattern)
        if (hasOscillationPattern(velocities)) {
            anomalyScore += 0.3;
            reasons.append("Oscillation detected; ");
        }
        
        // 5. Check for zero-velocity spam (anti-knockback)
        if (hasZeroVelocitySpam(velocities)) {
            anomalyScore += 0.4;
            reasons.append("Zero velocity spam; ");
        }
        
        return new PatternResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal pattern"
        );
    }
    
    /**
     * Calculate movement consistency (0.0 = random, 1.0 = perfectly consistent)
     */
    private static double calculateConsistency(List<Vector> velocities) {
        if (velocities.size() < 3) return 0.0;
        
        double totalVariation = 0.0;
        for (int i = 1; i < velocities.size(); i++) {
            double distance = velocities.get(i).distance(velocities.get(i - 1));
            totalVariation += distance;
        }
        
        double avgVariation = totalVariation / (velocities.size() - 1);
        
        // Low variation = high consistency
        return Math.max(0.0, 1.0 - (avgVariation * 10.0));
    }
    
    /**
     * Calculate maximum acceleration in the velocity history
     */
    private static double calculateMaxAcceleration(List<Vector> velocities) {
        if (velocities.size() < 2) return 0.0;
        
        double maxAccel = 0.0;
        for (int i = 1; i < velocities.size(); i++) {
            Vector v1 = velocities.get(i - 1);
            Vector v2 = velocities.get(i);
            
            double accel = v2.clone().subtract(v1).length();
            maxAccel = Math.max(maxAccel, accel);
        }
        
        return maxAccel;
    }
    
    /**
     * Detect teleport-like movement patterns
     */
    private static boolean hasTeleportPattern(List<Vector> velocities) {
        if (velocities.size() < 3) return false;
        
        int teleportCount = 0;
        for (int i = 1; i < velocities.size(); i++) {
            Vector v1 = velocities.get(i - 1);
            Vector v2 = velocities.get(i);
            
            // Sudden large change in velocity
            double change = v2.distance(v1);
            if (change > 1.5) {
                teleportCount++;
            }
        }
        
        // More than 20% of movements are teleport-like
        return teleportCount > velocities.size() * 0.2;
    }
    
    /**
     * Detect oscillation pattern (common in speed hacks)
     */
    private static boolean hasOscillationPattern(List<Vector> velocities) {
        if (velocities.size() < 6) return false;
        
        int oscillations = 0;
        for (int i = 2; i < velocities.size(); i++) {
            double speed1 = velocities.get(i - 2).length();
            double speed2 = velocities.get(i - 1).length();
            double speed3 = velocities.get(i).length();
            
            // Check for up-down-up or down-up-down pattern
            if ((speed2 > speed1 && speed2 > speed3) || (speed2 < speed1 && speed2 < speed3)) {
                oscillations++;
            }
        }
        
        // More than 40% oscillation
        return oscillations > (velocities.size() - 2) * 0.4;
    }
    
    /**
     * Detect zero velocity spam (anti-knockback indicator)
     */
    private static boolean hasZeroVelocitySpam(List<Vector> velocities) {
        if (velocities.size() < 5) return false;
        
        int zeroCount = 0;
        for (Vector v : velocities) {
            if (v.lengthSquared() < 0.001) {
                zeroCount++;
            }
        }
        
        // More than 60% zero velocity
        return zeroCount > velocities.size() * 0.6;
    }
    
    /**
     * Analyze rotation pattern for aim assistance
     */
    public static PatternResult analyzeRotationPattern(Deque<Double> yawChanges, Deque<Double> pitchChanges) {
        if (yawChanges.size() < 10) {
            return new PatternResult(0.0, "Insufficient data");
        }
        
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        List<Double> yawList = yawChanges.stream().collect(Collectors.toList());
        List<Double> pitchList = pitchChanges.stream().collect(Collectors.toList());
        
        // 1. Check for GCD (Greatest Common Divisor) patterns
        double gcd = calculateGCD(yawList);
        if (gcd > 0.5 && gcd < 2.0) {
            anomalyScore += 0.4;
            reasons.append("GCD pattern detected; ");
        }
        
        // 2. Check for constant rotation (aimbot)
        double yawVariance = MathUtil.getVariance(yawList);
        if (yawVariance < 1.0) {
            anomalyScore += 0.3;
            reasons.append("Low rotation variance; ");
        }
        
        // 3. Check for snap rotations (killaura)
        if (hasSnapRotations(yawList)) {
            anomalyScore += 0.5;
            reasons.append("Snap rotations; ");
        }
        
        // 4. Check for perfect tracking
        if (isPerfectTracking(yawList, pitchList)) {
            anomalyScore += 0.4;
            reasons.append("Perfect tracking; ");
        }
        
        return new PatternResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal rotation"
        );
    }
    
    /**
     * Calculate GCD of rotation changes
     */
    private static double calculateGCD(List<Double> values) {
        if (values.size() < 2) return 0.0;
        
        double gcd = values.get(0);
        for (int i = 1; i < Math.min(10, values.size()); i++) {
            gcd = MathUtil.getGcd(gcd, values.get(i));
        }
        
        return gcd;
    }
    
    /**
     * Detect snap rotations (instant large changes)
     */
    private static boolean hasSnapRotations(List<Double> rotations) {
        int snapCount = 0;
        for (double rotation : rotations) {
            if (rotation > 150.0) {
                snapCount++;
            }
        }
        
        return snapCount > rotations.size() * 0.1;
    }
    
    /**
     * Detect perfect tracking (too smooth)
     */
    private static boolean isPerfectTracking(List<Double> yaw, List<Double> pitch) {
        if (yaw.size() < 5 || pitch.size() < 5) return false;
        
        double yawVariance = MathUtil.getVariance(yaw);
        double pitchVariance = MathUtil.getVariance(pitch);
        
        // Both too consistent
        return yawVariance < 0.5 && pitchVariance < 0.5;
    }
    
    /**
     * Analyze click pattern for autoclicker detection
     */
    public static PatternResult analyzeClickPattern(Deque<Long> clickDelays) {
        if (clickDelays.size() < 10) {
            return new PatternResult(0.0, "Insufficient data");
        }
        
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        List<Long> delays = clickDelays.stream().collect(Collectors.toList());
        List<Double> delaysDouble = delays.stream().map(Long::doubleValue).collect(Collectors.toList());
        
        // 1. Check for too consistent clicking (autoclicker)
        double variance = MathUtil.getVariance(delaysDouble);
        if (variance < 100) {
            anomalyScore += 0.5;
            reasons.append("Robotic clicking; ");
        }
        
        // 2. Check for impossible CPS
        double avgDelay = delays.stream().mapToLong(Long::longValue).average().orElse(0.0);
        double cps = 1000.0 / avgDelay;
        if (cps > 25) {
            anomalyScore += 0.6;
            reasons.append("Impossible CPS: " + String.format("%.1f", cps) + "; ");
        }
        
        // 3. Check for pattern repetition
        if (hasRepeatingPattern(delays)) {
            anomalyScore += 0.4;
            reasons.append("Repeating pattern; ");
        }
        
        return new PatternResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal clicking"
        );
    }
    
    /**
     * Analyze speed pattern for speed hacks
     */
    public static PatternResult analyzeSpeedPattern(Deque<Double> speedHistory) {
        if (speedHistory.size() < 20) {
            return new PatternResult(0.0, "Insufficient data");
        }
        
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        List<Double> speeds = speedHistory.stream().collect(Collectors.toList());
        
        // 1. Check for consistently high speed
        double avgSpeed = speeds.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        if (avgSpeed > 0.5) {
            anomalyScore += 0.4;
            reasons.append("High average speed; ");
        }
        
        // 2. Check for speed oscillation
        if (hasSpeedOscillation(speeds)) {
            anomalyScore += 0.5;
            reasons.append("Speed oscillation; ");
        }
        
        // 3. Check for unnatural consistency
        double variance = MathUtil.getVariance(speeds);
        if (variance < 0.001) {
            anomalyScore += 0.3;
            reasons.append("Unnatural consistency; ");
        }
        
        return new PatternResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal speed"
        );
    }
    
    /**
     * Check for repeating patterns in click delays
     */
    private static boolean hasRepeatingPattern(List<Long> delays) {
        if (delays.size() < 6) return false;
        
        // Check for simple 2-3 value patterns
        for (int patternLength = 2; patternLength <= 3; patternLength++) {
            int matches = 0;
            for (int i = 0; i < delays.size() - patternLength * 2; i++) {
                boolean patternMatch = true;
                for (int j = 0; j < patternLength; j++) {
                    if (Math.abs(delays.get(i + j) - delays.get(i + j + patternLength)) > 5) {
                        patternMatch = false;
                        break;
                    }
                }
                if (patternMatch) matches++;
            }
            
            if (matches > delays.size() * 0.3) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check for speed oscillation pattern
     */
    private static boolean hasSpeedOscillation(List<Double> speeds) {
        if (speeds.size() < 6) return false;
        
        int oscillations = 0;
        for (int i = 2; i < speeds.size(); i++) {
            double s1 = speeds.get(i - 2);
            double s2 = speeds.get(i - 1);
            double s3 = speeds.get(i);
            
            if ((s2 > s1 && s2 > s3) || (s2 < s1 && s2 < s3)) {
                oscillations++;
            }
        }
        
        return oscillations > (speeds.size() - 2) * 0.4;
    }
    
    /**
     * Pattern analysis result
     */
    public static class PatternResult {
        public final double anomalyScore; // 0.0 = normal, 1.0 = definitely cheating
        public final String reason;
        
        public PatternResult(double anomalyScore, String reason) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
        }
        
        public boolean isAnomalous() {
            return anomalyScore > 0.5;
        }
        
        public boolean isHighlyAnomalous() {
            return anomalyScore > 0.7;
        }
    }
}
