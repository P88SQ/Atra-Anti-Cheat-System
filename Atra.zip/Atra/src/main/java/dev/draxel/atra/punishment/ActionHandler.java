package dev.draxel.atra.punishment;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

public class ActionHandler {
    
    private final AtraAC plugin;
    
    public ActionHandler(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public void executeAction(Player player, Check check, PunishmentType type, int violations) {
        switch (type) {
            case KICK:
                kick(player, check, violations);
                break;
            case BAN:
                ban(player, check, violations);
                break;
            case SETBACK:
                setback(player);
                break;
            case ALERT:
                // Already handled by AlertManager
                break;
        }
    }
    
    private void kick(Player player, Check check, int violations) {
        Component message = ColorUtil.translate(
            "<red><bold>Atra AntiCheat</bold></red>\n\n" +
            "<gray>Kirúgva: <white>" + check.getName() + "</white></gray>\n" +
            "<gray>Violation Level: <white>" + violations + "</white></gray>\n\n" +
            "<gray>Ha úgy gondolod, hogy ez hiba, lépj kapcsolatba a staff-al!</gray>"
        );
        
        Bukkit.getScheduler().runTask(plugin, () -> player.kick(message));
    }
    
    private void ban(Player player, Check check, int violations) {
        String reason = String.format("Atra AntiCheat - %s (VL: %d)", check.getName(), violations);
        
        Instant expiry = Instant.now().plus(Duration.ofDays(7));
        
        Bukkit.getBanList(BanList.Type.NAME).addBan(
            player.getName(),
            reason,
            Date.from(expiry),
            "Atra AntiCheat"
        );
        
        Component message = ColorUtil.translate(
            "<red><bold>Atra AntiCheat</bold></red>\n\n" +
            "<gray>Bannolva: <white>" + check.getName() + "</white></gray>\n" +
            "<gray>Violation Level: <white>" + violations + "</white></gray>\n" +
            "<gray>Időtartam: <white>7 nap</white></gray>\n\n" +
            "<gray>Ha úgy gondolod, hogy ez hiba, nyiss appeal-t!</gray>"
        );
        
        Bukkit.getScheduler().runTask(plugin, () -> player.kick(message));
    }
    
    private void setback(Player player) {
        var data = plugin.getPlayerDataManager().getPlayerData(player);
        var lastLoc = data.getMovementData().getLastLocation();
        
        if (lastLoc != null && lastLoc.getWorld() != null) {
            Bukkit.getScheduler().runTask(plugin, () -> player.teleport(lastLoc));
        }
    }
}
