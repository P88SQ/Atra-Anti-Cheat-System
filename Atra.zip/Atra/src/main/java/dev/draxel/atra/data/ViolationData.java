package dev.draxel.atra.data;

public class ViolationData {
    
    private final String checkName;
    private int violations;
    private long lastViolationTime;
    private long lastDecayTime;
    private double behaviorScore;
    
    public ViolationData(String checkName) {
        this.checkName = checkName;
        this.violations = 0;
        this.lastViolationTime = 0;
        this.lastDecayTime = System.currentTimeMillis();
        this.behaviorScore = 0.0;
    }
    
    public String getCheckName() {
        return checkName;
    }
    
    public int getViolations() {
        return violations;
    }
    
    public void addViolation(int amount) {
        this.violations += amount;
        this.lastViolationTime = System.currentTimeMillis();
    }
    
    public void setViolations(int violations) {
        this.violations = Math.max(0, violations);
    }
    
    public void decay(int amount) {
        this.violations = Math.max(0, violations - amount);
        this.lastDecayTime = System.currentTimeMillis();
    }
    
    public long getLastViolationTime() {
        return lastViolationTime;
    }
    
    public long getLastDecayTime() {
        return lastDecayTime;
    }
    
    public void reset() {
        this.violations = 0;
        this.lastViolationTime = 0;
    }
    
    public double getBehaviorScore() {
        return behaviorScore;
    }
    
    public void setBehaviorScore(double behaviorScore) {
        this.behaviorScore = Math.max(0.0, Math.min(1.0, behaviorScore));
    }
}
