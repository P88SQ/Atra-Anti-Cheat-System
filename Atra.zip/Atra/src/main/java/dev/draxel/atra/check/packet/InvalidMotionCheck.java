package dev.draxel.atra.check.packet;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class InvalidMotionCheck extends Check {
    
    public InvalidMotionCheck(AtraAC plugin) {
        super(plugin, "InvalidMotion", CheckType.PACKET);
    }
    
    public void checkMotion(Player player, Vector motion) {
        if (!enabled) return;
        
        // Check for invalid motion values
        if (Double.isNaN(motion.getX()) || Double.isNaN(motion.getY()) || Double.isNaN(motion.getZ())) {
            flag(player, "NaN motion values", 50);
            return;
        }
        
        if (Double.isInfinite(motion.getX()) || Double.isInfinite(motion.getY()) || Double.isInfinite(motion.getZ())) {
            flag(player, "Infinite motion values", 50);
            return;
        }
        
        // Check for impossible motion
        double motionLength = motion.length();
        if (motionLength > 10.0) {
            flag(player, String.format("Impossible motion: %.2f", motionLength), 20);
        }
    }
}
