package dev.draxel.atra.config;

import dev.draxel.atra.AtraAC;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
    
    private final AtraAC plugin;
    private FileConfiguration config;
    private boolean debugEnabled;
    
    public ConfigManager(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public void loadConfigs() {
        plugin.saveDefaultConfig();
        config = plugin.getConfig();
        
        debugEnabled = config.getBoolean("debug", false);
    }
    
    public void reloadConfigs() {
        plugin.reloadConfig();
        loadConfigs();
    }
    
    public boolean isDebugEnabled() {
        return debugEnabled;
    }
    
    public FileConfiguration getConfig() {
        return config;
    }
}
