package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.CombatData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.LocationUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class KillAuraCheck extends Check {
    
    private static final double MAX_YAW_CHANGE = 180.0;
    private static final double SUSPICIOUS_YAW_CHANGE = 150.0;
    
    public KillAuraCheck(AtraAC plugin) {
        super(plugin, "KillAura", CheckType.COMBAT);
    }
    
    public void checkRotation(Player player, Entity target, float yaw, float pitch) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        CombatData combatData = data.getCombatData();
        
        combatData.updateRotation(yaw, pitch);
        
        // Check for impossible rotations
        if (!combatData.getYawChanges().isEmpty()) {
            double lastYawChange = combatData.getYawChanges().getLast();
            
            if (lastYawChange > SUSPICIOUS_YAW_CHANGE) {
                flag(player, String.format("Suspicious rotation: %.2f° yaw change", lastYawChange), 5);
            }
            
            // Check for perfect aim (always hitting center)
            if (combatData.getYawChanges().size() >= 10) {
                double avgYawChange = combatData.getYawChanges().stream()
                        .mapToDouble(Double::doubleValue)
                        .average()
                        .orElse(0.0);
                
                if (avgYawChange < 1.0 && combatData.getHitCount() > 5) {
                    flag(player, "Robotic aim pattern detected", 3);
                }
            }
        }
    }
    
    public void checkMultiTarget(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        CombatData combatData = data.getCombatData();
        
        // Check if attacking multiple entities too quickly
        long timeSinceLastHit = System.currentTimeMillis() - combatData.getLastHitTime();
        
        if (timeSinceLastHit < 100 && combatData.getLastTarget() != null) {
            flag(player, "Multi-target attack detected", 10);
        }
    }
}
