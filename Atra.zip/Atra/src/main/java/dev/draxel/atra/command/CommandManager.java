package dev.draxel.atra.command;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.command.subcommands.*;
import org.bukkit.command.CommandSender;

import java.util.HashMap;
import java.util.Map;

public class CommandManager {
    
    private final AtraAC plugin;
    private final Map<String, SubCommand> subCommands;
    
    public CommandManager(AtraAC plugin) {
        this.plugin = plugin;
        this.subCommands = new HashMap<>();
        
        registerSubCommands();
    }
    
    private void registerSubCommands() {
        subCommands.put("alerts", new AlertsCommand(plugin));
        subCommands.put("info", new InfoCommand(plugin));
        subCommands.put("reset", new ResetCommand(plugin));
        subCommands.put("debug", new DebugCommand(plugin));
        subCommands.put("reload", new ReloadCommand(plugin));
        subCommands.put("behavior", new BehaviorCommand(plugin));
    }
    
    public boolean executeCommand(CommandSender sender, String[] args) {
        if (args.length == 0) {
            return false;
        }
        
        SubCommand subCommand = subCommands.get(args[0].toLowerCase());
        
        if (subCommand == null) {
            return false;
        }
        
        return subCommand.execute(sender, args);
    }
    
    public Map<String, SubCommand> getSubCommands() {
        return subCommands;
    }
}
