package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.CombatData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.PatternAnalyzer;
import dev.draxel.atra.util.MathUtil;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class AimAssistCheck extends Check {
    
    public AimAssistCheck(AtraAC plugin) {
        super(plugin, "AimAssist", CheckType.COMBAT);
    }
    
    public void checkAim(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        CombatData combatData = data.getCombatData();
        
        if (combatData.getYawChanges().size() < 20) return;
        
        List<Double> yawChanges = new ArrayList<>(combatData.getYawChanges());
        
        // Advanced rotation pattern analysis
        if (combatData.getPitchChanges().size() >= 20) {
            PatternAnalyzer.PatternResult aimPattern = PatternAnalyzer.analyzeRotationPattern(
                combatData.getYawChanges(),
                combatData.getPitchChanges()
            );
            
            if (aimPattern.isAnomalous()) {
                int violationLevel = (int) (aimPattern.anomalyScore * 15);
                flag(player, "Aim pattern anomaly: " + aimPattern.reason, violationLevel);
            }
        }
        
        // Check for GCD (Greatest Common Divisor) patterns
        double gcd = yawChanges.get(0);
        for (int i = 1; i < Math.min(10, yawChanges.size()); i++) {
            gcd = MathUtil.getGcd(gcd, yawChanges.get(i));
        }
        
        if (gcd > 0.5 && gcd < 2.0) {
            flag(player, String.format("Suspicious GCD pattern: %.4f", gcd), 5);
        }
        
        // Check for constant rotation patterns
        double variance = MathUtil.getVariance(yawChanges);
        if (variance < 1.0 && combatData.getHitCount() > 5) {
            flag(player, String.format("Low rotation variance: %.2f", variance), 3);
        }
        
        // Check for aim lock patterns (constant small adjustments)
        long smallAdjustments = yawChanges.stream()
            .filter(change -> change > 0.1 && change < 2.0)
            .count();
        
        double smallAdjustmentRatio = (double) smallAdjustments / yawChanges.size();
        if (smallAdjustmentRatio > 0.8) {
            flag(player, String.format("Aim lock pattern detected (%.1f%% micro-adjustments)", 
                smallAdjustmentRatio * 100), 10);
        }
        
        // Check accuracy combined with rotation patterns
        int totalShots = combatData.getHitCount() + combatData.getMissCount();
        if (totalShots > 20) {
            double accuracy = (double) combatData.getHitCount() / totalShots;
            
            if (accuracy > 0.95 && variance < 1.0) {
                flag(player, String.format("Suspicious accuracy with low variance: %.1f%% (var: %.2f)", 
                    accuracy * 100, variance), 8);
            }
        }
    }
}
