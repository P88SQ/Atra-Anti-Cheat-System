package dev.draxel.atra.util.version;

import org.bukkit.Bukkit;

public enum ServerVersion {
    
    v1_8_R3("1.8", 8),
    v1_9_R1("1.9", 9),
    v1_9_R2("1.9", 9),
    v1_10_R1("1.10", 10),
    v1_11_R1("1.11", 11),
    v1_12_R1("1.12", 12),
    v1_13_R1("1.13", 13),
    v1_13_R2("1.13", 13),
    v1_14_R1("1.14", 14),
    v1_15_R1("1.15", 15),
    v1_16_R1("1.16", 16),
    v1_16_R2("1.16", 16),
    v1_16_R3("1.16", 16),
    v1_17_R1("1.17", 17),
    v1_18_R1("1.18", 18),
    v1_18_R2("1.18", 18),
    v1_19_R1("1.19", 19),
    v1_19_R2("1.19", 19),
    v1_19_R3("1.19", 19),
    v1_20_R1("1.20", 20),
    v1_20_R2("1.20", 20),
    v1_20_R3("1.20", 20),
    v1_21_R1("1.21", 21),
    UNKNOWN("Unknown", 0);
    
    private final String versionString;
    private final int versionNumber;
    
    ServerVersion(String versionString, int versionNumber) {
        this.versionString = versionString;
        this.versionNumber = versionNumber;
    }
    
    public String getVersionString() {
        return versionString;
    }
    
    public int getVersionNumber() {
        return versionNumber;
    }
    
    public boolean isNewerThan(ServerVersion other) {
        return this.versionNumber > other.versionNumber;
    }
    
    public boolean isOlderThan(ServerVersion other) {
        return this.versionNumber < other.versionNumber;
    }
    
    public boolean isAtLeast(ServerVersion other) {
        return this.versionNumber >= other.versionNumber;
    }
    
    public static ServerVersion getServerVersion() {
        String version = Bukkit.getServer().getClass().getPackage().getName();
        String nmsVersion = version.substring(version.lastIndexOf('.') + 1);
        
        try {
            return ServerVersion.valueOf(nmsVersion);
        } catch (IllegalArgumentException e) {
            // Try to detect from Bukkit version string
            String bukkitVersion = Bukkit.getVersion();
            
            if (bukkitVersion.contains("1.8")) return v1_8_R3;
            if (bukkitVersion.contains("1.9")) return v1_9_R2;
            if (bukkitVersion.contains("1.10")) return v1_10_R1;
            if (bukkitVersion.contains("1.11")) return v1_11_R1;
            if (bukkitVersion.contains("1.12")) return v1_12_R1;
            if (bukkitVersion.contains("1.13")) return v1_13_R2;
            if (bukkitVersion.contains("1.14")) return v1_14_R1;
            if (bukkitVersion.contains("1.15")) return v1_15_R1;
            if (bukkitVersion.contains("1.16")) return v1_16_R3;
            if (bukkitVersion.contains("1.17")) return v1_17_R1;
            if (bukkitVersion.contains("1.18")) return v1_18_R2;
            if (bukkitVersion.contains("1.19")) return v1_19_R3;
            if (bukkitVersion.contains("1.20")) return v1_20_R3;
            if (bukkitVersion.contains("1.21")) return v1_21_R1;
            
            return UNKNOWN;
        }
    }
}
