package dev.draxel.atra.check.combat;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;

public class CriticalsCheck extends Check {
    
    public CriticalsCheck(AtraAC plugin) {
        super(plugin, "Criticals", CheckType.COMBAT);
    }
    
    public void checkCritical(Player player, boolean isCritical) {
        if (!enabled || !isCritical) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        // Check if player is actually falling
        boolean onGround = player.isOnGround();
        double fallDistance = movementData.getFallDistance();
        
        if (onGround && fallDistance < 0.1) {
            flag(player, "Critical hit from ground", 15);
        }
        
        // Check if in water/lava
        if (player.isInWater() || player.isInLava()) {
            flag(player, "Critical hit in liquid", 15);
        }
    }
}
