package dev.draxel.atra.data;

import org.bukkit.Location;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;

public class MovementData {
    
    private Location lastLocation;
    private Location currentLocation;
    
    private final Deque<Vector> velocityHistory;
    private final Deque<Double> speedHistory;
    
    private Vector lastVelocity;
    private long lastMoveTime;
    private int airTicks;
    private int groundTicks;
    
    private boolean wasOnGround;
    private double fallDistance;
    
    public MovementData() {
        this.velocityHistory = new ArrayDeque<>();
        this.speedHistory = new ArrayDeque<>();
        
        this.lastMoveTime = System.currentTimeMillis();
        this.airTicks = 0;
        this.groundTicks = 0;
        this.wasOnGround = true;
        this.fallDistance = 0.0;
    }
    
    public void updateLocation(Location location, boolean onGround) {
        this.lastLocation = this.currentLocation;
        this.currentLocation = location.clone();
        this.lastMoveTime = System.currentTimeMillis();
        
        if (lastLocation != null) {
            Vector velocity = location.toVector().subtract(lastLocation.toVector());
            velocityHistory.add(velocity);
            if (velocityHistory.size() > 20) {
                velocityHistory.removeFirst();
            }
            
            double speed = Math.sqrt(velocity.getX() * velocity.getX() + velocity.getZ() * velocity.getZ());
            speedHistory.add(speed);
            if (speedHistory.size() > 20) {
                speedHistory.removeFirst();
            }
            
            this.lastVelocity = velocity;
        }
        
        if (onGround) {
            groundTicks++;
            airTicks = 0;
            fallDistance = 0.0;
        } else {
            airTicks++;
            groundTicks = 0;
            if (lastLocation != null && location.getY() < lastLocation.getY()) {
                fallDistance += lastLocation.getY() - location.getY();
            }
        }
        
        this.wasOnGround = onGround;
    }
    
    public Location getLastLocation() {
        return lastLocation;
    }
    
    public Location getCurrentLocation() {
        return currentLocation;
    }
    
    public Vector getLastVelocity() {
        return lastVelocity;
    }
    
    public Deque<Vector> getVelocityHistory() {
        return velocityHistory;
    }
    
    public Deque<Double> getSpeedHistory() {
        return speedHistory;
    }
    
    public long getLastMoveTime() {
        return lastMoveTime;
    }
    
    public int getAirTicks() {
        return airTicks;
    }
    
    public int getGroundTicks() {
        return groundTicks;
    }
    
    public boolean wasOnGround() {
        return wasOnGround;
    }
    
    public boolean isOnGround() {
        return wasOnGround;
    }
    
    public double getFallDistance() {
        return fallDistance;
    }
    
    public void setFallDistance(double distance) {
        this.fallDistance = distance;
    }
}
