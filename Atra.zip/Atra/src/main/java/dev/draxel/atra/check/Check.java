package dev.draxel.atra.check;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.api.events.FlagEvent;
import dev.draxel.atra.api.events.ViolationEvent;
import dev.draxel.atra.api.interfaces.ICheck;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.data.ViolationData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public abstract class Check implements ICheck {
    
    protected final AtraAC plugin;
    protected final String name;
    protected final CheckType type;
    protected boolean enabled;
    protected int maxViolations;
    
    public Check(AtraAC plugin, String name, CheckType type) {
        this.plugin = plugin;
        this.name = name;
        this.type = type;
        this.enabled = true;
        this.maxViolations = 50;
    }
    
    protected void flag(Player player, String information) {
        flag(player, information, 1);
    }
    
    protected void flag(Player player, String information, int violationIncrease) {
        if (!enabled) return;
        
        FlagEvent flagEvent = new FlagEvent(player, this, information);
        Bukkit.getPluginManager().callEvent(flagEvent);
        
        if (flagEvent.isCancelled()) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        ViolationData violationData = data.getViolationData(name);
        
        int oldVL = violationData.getViolations();
        violationData.addViolation(violationIncrease);
        int newVL = violationData.getViolations();
        
        ViolationEvent violationEvent = new ViolationEvent(player, this, newVL, violationIncrease);
        Bukkit.getPluginManager().callEvent(violationEvent);
        
        if (!violationEvent.isCancelled()) {
            plugin.getAlertManager().sendAlert(player, this, information, newVL);
            plugin.getPunishmentManager().handleViolation(player, this, newVL);
        }
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public CheckType getType() {
        return type;
    }
    
    @Override
    public boolean isEnabled() {
        return enabled;
    }
    
    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    @Override
    public int getMaxViolations() {
        return maxViolations;
    }
    
    public void setMaxViolations(int maxViolations) {
        this.maxViolations = maxViolations;
    }
}
