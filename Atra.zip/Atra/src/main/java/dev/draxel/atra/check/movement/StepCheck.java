package dev.draxel.atra.check.movement;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.PlayerUtil;
import org.bukkit.entity.Player;

public class StepCheck extends Check {
    
    private static final double MAX_STEP_HEIGHT = 0.6;
    
    public StepCheck(AtraAC plugin) {
        super(plugin, "Step", CheckType.MOVEMENT);
    }
    
    public void checkStep(Player player) {
        if (!enabled) return;
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        if (movementData.getLastLocation() == null || movementData.getCurrentLocation() == null) return;
        
        double yDiff = movementData.getCurrentLocation().getY() - movementData.getLastLocation().getY();
        
        // Check if this is a step (not a jump)
        if (yDiff > MAX_STEP_HEIGHT && yDiff < PlayerUtil.getJumpHeight(player) && 
            movementData.wasOnGround() && player.isOnGround()) {
            
            flag(player, String.format("Invalid step: %.2f blocks", yDiff), 10);
        }
    }
}
