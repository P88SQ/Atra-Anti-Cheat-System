package dev.draxel.atra.listener;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.BehaviorAnalyzer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Listener that periodically analyzes player behavior patterns
 */
public class BehaviorListener {
    
    private final AtraAC plugin;
    private static final int ANALYSIS_INTERVAL = 100; // 5 seconds (100 ticks)
    
    public BehaviorListener(AtraAC plugin) {
        this.plugin = plugin;
        startBehaviorAnalysis();
    }
    
    private void startBehaviorAnalysis() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.hasPermission("atra.bypass")) continue;
                    
                    analyzeBehavior(player);
                }
            }
        }.runTaskTimerAsynchronously(plugin, ANALYSIS_INTERVAL, ANALYSIS_INTERVAL);
    }
    
    private void analyzeBehavior(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        
        // Run behavior analysis
        BehaviorAnalyzer.BehaviorAnalysisResult result = BehaviorAnalyzer.analyzeBehavior(player, data);
        
        // If anomaly score is high, alert staff
        if (result.anomalyScore > 0.7) {
            String message = String.format("§c[Behavior] §f%s §7has high anomaly score: §c%.2f §7(%s)", 
                player.getName(), result.anomalyScore, result.reason);
            
            // Send alert to all staff members
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("atra.alerts")) {
                    staff.sendMessage(message);
                }
            }
        }
        
        // Store the result for later analysis (if needed in the future)
        // data.getViolationData("behavior").setBehaviorScore(result.anomalyScore);
    }
}
