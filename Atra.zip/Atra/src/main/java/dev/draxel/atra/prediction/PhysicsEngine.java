package dev.draxel.atra.prediction;

import dev.draxel.atra.util.PlayerUtil;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class PhysicsEngine {
    
    private static final double GRAVITY = 0.08;
    private static final double AIR_RESISTANCE = 0.98;
    private static final double GROUND_FRICTION = 0.6;
    private static final double DRAG = 0.91;
    
    public static class PhysicsResult {
        public final Vector velocity;
        public final boolean isValid;
        public final String reason;
        public final double deviation;
        
        public PhysicsResult(Vector velocity, boolean isValid, String reason) {
            this.velocity = velocity;
            this.isValid = isValid;
            this.reason = reason;
            this.deviation = 0.0;
        }
        
        public PhysicsResult(Vector velocity, boolean isValid, String reason, double deviation) {
            this.velocity = velocity;
            this.isValid = isValid;
            this.reason = reason;
            this.deviation = deviation;
        }
    }
    
    public Vector applyPhysics(Player player, Vector velocity) {
        return applyPhysics(player, velocity, player.isOnGround());
    }
    
    public Vector applyPhysics(Player player, Vector velocity, boolean onGround) {
        Vector result = velocity.clone();
        
        // Check for version-specific movement states
        boolean isSwimming = PlayerUtil.isSwimming(player);
        boolean isRiptiding = PlayerUtil.isRiptiding(player);
        boolean hasSlowFalling = PlayerUtil.hasSlowFalling(player);
        boolean hasLevitation = PlayerUtil.hasLevitation(player);
        
        // Apply gravity
        if (!onGround && !player.isFlying() && !player.isGliding() && !isRiptiding && !hasLevitation) {
            double gravityModifier = hasSlowFalling ? 0.01 : GRAVITY;
            result.setY(result.getY() - gravityModifier);
            result.setY(result.getY() * AIR_RESISTANCE);
        }
        
        // Apply friction
        if (onGround && !isSwimming) {
            result.setX(result.getX() * GROUND_FRICTION);
            result.setZ(result.getZ() * GROUND_FRICTION);
        } else if (!isSwimming) {
            result.setX(result.getX() * DRAG);
            result.setZ(result.getZ() * DRAG);
        }
        
        return result;
    }
    
    public double calculateMaxSpeed(Player player) {
        double baseSpeed = PlayerUtil.getBaseSpeed(player);
        
        // Add modifiers
        if (player.isFlying()) {
            baseSpeed *= 2.0;
        }
        
        if (player.isGliding()) {
            baseSpeed *= 3.0;
        }
        
        // Swimming modifier (1.13+)
        if (PlayerUtil.isSwimming(player)) {
            baseSpeed *= 0.8;
        }
        
        // Riptiding (1.13+)
        if (PlayerUtil.isRiptiding(player)) {
            baseSpeed *= 4.0;
        }
        
        return baseSpeed;
    }
    
    public double calculateJumpVelocity(Player player) {
        double baseJump = 0.42;
        
        if (player.hasPotionEffect(PotionEffectType.JUMP_BOOST)) {
            int amplifier = player.getPotionEffect(PotionEffectType.JUMP_BOOST).getAmplifier();
            baseJump += 0.1 * (amplifier + 1);
        }
        
        return baseJump;
    }
    
    /**
     * Simulate exact Minecraft movement for one tick
     */
    public Vector simulateMovementTick(Player player, Vector velocity, boolean onGround, Vector input) {
        Vector result = velocity.clone();
        
        // Apply input (WASD movement)
        if (input != null && input.lengthSquared() > 0) {
            double inputStrength = 0.98;
            result.add(input.clone().multiply(inputStrength));
        }
        
        // Apply physics
        result = applyPhysics(player, result, onGround);
        
        // Clamp to max speed
        double maxSpeed = calculateMaxSpeed(player);
        double horizontalSpeed = Math.sqrt(result.getX() * result.getX() + result.getZ() * result.getZ());
        
        if (horizontalSpeed > maxSpeed) {
            double ratio = maxSpeed / horizontalSpeed;
            result.setX(result.getX() * ratio);
            result.setZ(result.getZ() * ratio);
        }
        
        return result;
    }
    
    /**
     * Calculate expected velocity after knockback
     */
    public Vector calculateKnockback(Vector attackerLocation, Vector victimLocation, double knockbackStrength) {
        Vector direction = victimLocation.clone().subtract(attackerLocation).normalize();
        
        // Horizontal knockback
        direction.setY(0);
        direction.normalize();
        direction.multiply(knockbackStrength * 0.4);
        
        // Vertical knockback
        direction.setY(0.4);
        
        return direction;
    }
    
    /**
     * Check if velocity is within expected range
     */
    public boolean isVelocityValid(Player player, Vector velocity, double tolerance) {
        double maxSpeed = calculateMaxSpeed(player) * (1.0 + tolerance);
        double horizontalSpeed = Math.sqrt(velocity.getX() * velocity.getX() + velocity.getZ() * velocity.getZ());
        
        return horizontalSpeed <= maxSpeed;
    }
    
    /**
     * Simulate movement with full physics validation
     */
    public static PhysicsResult simulateMovement(Player player, Vector velocity, Vector lastVelocity, boolean onGround) {
        PhysicsEngine engine = new PhysicsEngine();
        Vector simulated = engine.applyPhysics(player, lastVelocity, onGround);
        
        double deviation = simulated.distance(velocity);
        boolean isValid = deviation < 0.1; // 0.1 block tolerance
        
        String reason = isValid ? "Valid movement" : "Deviation: " + String.format("%.3f", deviation);
        
        return new PhysicsResult(simulated, isValid, reason, deviation);
    }
}
