package dev.draxel.atra.api;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;

import java.util.List;

public class AtraAPI {
    
    private static final AtraAC plugin = AtraAC.getInstance();
    
    public static PlayerData getPlayerData(Player player) {
        return plugin.getPlayerDataManager().getPlayerData(player);
    }
    
    public static List<Check> getChecks() {
        return plugin.getCheckManager().getChecks();
    }
    
    public static Check getCheck(String name) {
        return plugin.getCheckManager().getCheck(name);
    }
    
    public static void resetViolations(Player player, String checkName) {
        PlayerData data = getPlayerData(player);
        if (data != null) {
            data.resetViolations(checkName);
        }
    }
    
    public static void resetAllViolations(Player player) {
        PlayerData data = getPlayerData(player);
        if (data != null) {
            data.resetAllViolations();
        }
    }
}
