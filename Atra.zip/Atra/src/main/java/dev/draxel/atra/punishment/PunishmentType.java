package dev.draxel.atra.punishment;

public enum PunishmentType {
    ALERT,
    KICK,
    BAN,
    SETBACK
}
