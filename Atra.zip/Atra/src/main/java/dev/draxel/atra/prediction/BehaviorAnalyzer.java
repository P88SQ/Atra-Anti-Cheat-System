package dev.draxel.atra.prediction;

import dev.draxel.atra.data.CombatData;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Advanced behavior analysis using statistical methods and pattern recognition
 */
public class BehaviorAnalyzer {
    
    // Behavior profile for a player
    public static class BehaviorProfile {
        private final Map<String, Double> features = new HashMap<>();
        private final List<Double> anomalyHistory = new ArrayList<>();
        private long lastUpdate = System.currentTimeMillis();
        
        public void updateFeature(String name, double value) {
            features.put(name, value);
            lastUpdate = System.currentTimeMillis();
        }
        
        public double getFeature(String name) {
            return features.getOrDefault(name, 0.0);
        }
        
        public void addAnomalyScore(double score) {
            anomalyHistory.add(score);
            if (anomalyHistory.size() > 100) {
                anomalyHistory.remove(0);
            }
        }
        
        public double getAverageAnomalyScore() {
            return anomalyHistory.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        }
        
        public boolean isStale() {
            return System.currentTimeMillis() - lastUpdate > 300000; // 5 minutes
        }
    }
    
    private static final Map<UUID, BehaviorProfile> profiles = new HashMap<>();
    
    /**
     * Analyze player behavior and return anomaly score
     */
    public static BehaviorAnalysisResult analyzeBehavior(Player player, PlayerData data) {
        BehaviorProfile profile = profiles.computeIfAbsent(player.getUniqueId(), k -> new BehaviorProfile());
        
        // Clean up stale profiles
        if (profile.isStale()) {
            profiles.remove(player.getUniqueId());
            profile = new BehaviorProfile();
            profiles.put(player.getUniqueId(), profile);
        }
        
        double totalAnomalyScore = 0.0;
        List<String> anomalies = new ArrayList<>();
        
        // 1. Movement Analysis
        MovementAnalysisResult movementResult = analyzeMovementBehavior(data.getMovementData(), profile);
        totalAnomalyScore += movementResult.anomalyScore * 0.3;
        if (movementResult.anomalyScore > 0.5) {
            anomalies.add("Movement: " + movementResult.reason);
        }
        
        // 2. Combat Analysis
        CombatAnalysisResult combatResult = analyzeCombatBehavior(data.getCombatData(), profile);
        totalAnomalyScore += combatResult.anomalyScore * 0.4;
        if (combatResult.anomalyScore > 0.5) {
            anomalies.add("Combat: " + combatResult.reason);
        }
        
        // 3. Timing Analysis
        TimingAnalysisResult timingResult = analyzeTimingBehavior(data, profile);
        totalAnomalyScore += timingResult.anomalyScore * 0.3;
        if (timingResult.anomalyScore > 0.5) {
            anomalies.add("Timing: " + timingResult.reason);
        }
        
        // Update profile
        profile.addAnomalyScore(totalAnomalyScore);
        
        return new BehaviorAnalysisResult(
                Math.min(1.0, totalAnomalyScore),
                String.join("; ", anomalies),
                profile.getAverageAnomalyScore()
        );
    }
    
    /**
     * Analyze movement behavior patterns
     */
    private static MovementAnalysisResult analyzeMovementBehavior(MovementData movementData, BehaviorProfile profile) {
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        if (movementData.getSpeedHistory().size() < 5) {
            return new MovementAnalysisResult(0.0, "Insufficient data");
        }
        
        List<Double> speeds = new ArrayList<>(movementData.getSpeedHistory());
        
        // 1. Speed consistency analysis
        double speedVariance = calculateVariance(speeds);
        profile.updateFeature("speed_variance", speedVariance);
        
        if (speedVariance < 0.001) {
            anomalyScore += 0.4;
            reasons.append("Unnatural speed consistency; ");
        }
        
        // 2. Acceleration pattern analysis
        List<Double> accelerations = calculateAccelerations(speeds);
        double maxAcceleration = accelerations.stream().mapToDouble(Double::doubleValue).max().orElse(0.0);
        profile.updateFeature("max_acceleration", maxAcceleration);
        
        if (maxAcceleration > 1.5) {
            anomalyScore += 0.3;
            reasons.append("Impossible acceleration; ");
        }
        
        // 3. Direction change analysis
        if (movementData.getVelocityHistory().size() >= 5) {
            double directionChanges = analyzeDirectionChanges(movementData.getVelocityHistory());
            profile.updateFeature("direction_changes", directionChanges);
            
            if (directionChanges > 0.8) {
                anomalyScore += 0.2;
                reasons.append("Erratic movement; ");
            }
        }
        
        return new MovementAnalysisResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal movement"
        );
    }
    
    /**
     * Analyze combat behavior patterns
     */
    private static CombatAnalysisResult analyzeCombatBehavior(CombatData combatData, BehaviorProfile profile) {
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        // 1. Click pattern analysis
        if (combatData.getClickTimes().size() >= 10) {
            List<Long> clickDelays = calculateClickDelays(combatData.getClickTimes());
            double clickVariance = calculateVariance(clickDelays.stream().map(Long::doubleValue).collect(Collectors.toList()));
            profile.updateFeature("click_variance", clickVariance);
            
            if (clickVariance < 100) {
                anomalyScore += 0.4;
                reasons.append("Robotic clicking; ");
            }
        }
        
        // 2. Rotation analysis
        if (combatData.getYawChanges().size() >= 10) {
            List<Double> yawChanges = new ArrayList<>(combatData.getYawChanges());
            double rotationVariance = calculateVariance(yawChanges);
            profile.updateFeature("rotation_variance", rotationVariance);
            
            if (rotationVariance < 1.0) {
                anomalyScore += 0.3;
                reasons.append("Unnatural aim; ");
            }
            
            // Check for snap rotations
            long snapCount = yawChanges.stream().mapToLong(change -> change > 150 ? 1 : 0).sum();
            if (snapCount > yawChanges.size() * 0.1) {
                anomalyScore += 0.4;
                reasons.append("Snap rotations; ");
            }
        }
        
        // 3. Hit accuracy analysis
        if (combatData.getHitCount() + combatData.getMissCount() > 10) {
            double accuracy = (double) combatData.getHitCount() / (combatData.getHitCount() + combatData.getMissCount());
            profile.updateFeature("hit_accuracy", accuracy);
            
            if (accuracy > 0.95) {
                anomalyScore += 0.3;
                reasons.append("Superhuman accuracy; ");
            }
        }
        
        return new CombatAnalysisResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal combat"
        );
    }
    
    /**
     * Analyze timing behavior (reaction times, etc.)
     */
    private static TimingAnalysisResult analyzeTimingBehavior(PlayerData data, BehaviorProfile profile) {
        double anomalyScore = 0.0;
        StringBuilder reasons = new StringBuilder();
        
        // 1. Reaction time analysis
        CombatData combatData = data.getCombatData();
        if (combatData.getClickTimes().size() >= 5) {
            List<Long> reactionTimes = calculateReactionTimes(combatData);
            if (!reactionTimes.isEmpty()) {
                double avgReactionTime = reactionTimes.stream().mapToLong(Long::longValue).average().orElse(0.0);
                profile.updateFeature("avg_reaction_time", avgReactionTime);
                
                if (avgReactionTime < 50) { // Less than 50ms is superhuman
                    anomalyScore += 0.5;
                    reasons.append("Superhuman reactions; ");
                }
            }
        }
        
        // 2. Action timing consistency
        double timingConsistency = calculateTimingConsistency(data);
        profile.updateFeature("timing_consistency", timingConsistency);
        
        if (timingConsistency > 0.95) {
            anomalyScore += 0.3;
            reasons.append("Robotic timing; ");
        }
        
        return new TimingAnalysisResult(
                Math.min(1.0, anomalyScore),
                reasons.length() > 0 ? reasons.toString() : "Normal timing"
        );
    }
    
    // Helper methods
    private static double calculateVariance(List<Double> values) {
        if (values.size() < 2) return 0.0;
        
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        double variance = values.stream()
                .mapToDouble(value -> Math.pow(value - mean, 2))
                .average()
                .orElse(0.0);
        
        return variance;
    }
    
    private static List<Double> calculateAccelerations(List<Double> speeds) {
        List<Double> accelerations = new ArrayList<>();
        for (int i = 1; i < speeds.size(); i++) {
            accelerations.add(Math.abs(speeds.get(i) - speeds.get(i - 1)));
        }
        return accelerations;
    }
    
    private static double analyzeDirectionChanges(Deque<org.bukkit.util.Vector> velocityHistory) {
        if (velocityHistory.size() < 3) return 0.0;
        
        org.bukkit.util.Vector[] velocities = velocityHistory.toArray(new org.bukkit.util.Vector[0]);
        int changes = 0;
        
        for (int i = 2; i < velocities.length; i++) {
            org.bukkit.util.Vector v1 = velocities[i - 2];
            org.bukkit.util.Vector v2 = velocities[i - 1];
            org.bukkit.util.Vector v3 = velocities[i];
            
            double angle1 = v1.angle(v2);
            double angle2 = v2.angle(v3);
            
            if (Math.abs(angle1 - angle2) > Math.PI / 4) {
                changes++;
            }
        }
        
        return (double) changes / (velocities.length - 2);
    }
    
    private static List<Long> calculateClickDelays(Deque<Long> clickTimes) {
        List<Long> delays = new ArrayList<>();
        Long[] times = clickTimes.toArray(new Long[0]);
        
        for (int i = 1; i < times.length; i++) {
            delays.add(times[i] - times[i - 1]);
        }
        
        return delays;
    }
    
    private static List<Long> calculateReactionTimes(CombatData combatData) {
        // Simplified - would need more complex logic to determine actual reaction times
        return new ArrayList<>();
    }
    
    private static double calculateTimingConsistency(PlayerData data) {
        // Simplified - analyze consistency of various timed actions
        return 0.5;
    }
    
    // Result classes
    public static class BehaviorAnalysisResult {
        public final double anomalyScore;
        public final String reason;
        public final double historicalAverage;
        
        public BehaviorAnalysisResult(double anomalyScore, String reason, double historicalAverage) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
            this.historicalAverage = historicalAverage;
        }
    }
    
    private static class MovementAnalysisResult {
        final double anomalyScore;
        final String reason;
        
        MovementAnalysisResult(double anomalyScore, String reason) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
        }
    }
    
    private static class CombatAnalysisResult {
        final double anomalyScore;
        final String reason;
        
        CombatAnalysisResult(double anomalyScore, String reason) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
        }
    }
    
    private static class TimingAnalysisResult {
        final double anomalyScore;
        final String reason;
        
        TimingAnalysisResult(double anomalyScore, String reason) {
            this.anomalyScore = anomalyScore;
            this.reason = reason;
        }
    }
}
