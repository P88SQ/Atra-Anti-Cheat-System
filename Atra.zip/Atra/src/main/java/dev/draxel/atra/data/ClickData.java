package dev.draxel.atra.data;

import java.util.ArrayDeque;
import java.util.Deque;

public class ClickData {
    
    private final Deque<Long> clickTimestamps;
    private final Deque<Long> clickDelays;
    
    private long lastClickTime;
    private int cps;
    
    public ClickData() {
        this.clickTimestamps = new ArrayDeque<>();
        this.clickDelays = new ArrayDeque<>();
        this.lastClickTime = 0;
        this.cps = 0;
    }
    
    public void addClick() {
        long currentTime = System.currentTimeMillis();
        
        if (lastClickTime > 0) {
            long delay = currentTime - lastClickTime;
            clickDelays.add(delay);
            if (clickDelays.size() > 100) {
                clickDelays.removeFirst();
            }
        }
        
        clickTimestamps.add(currentTime);
        if (clickTimestamps.size() > 100) {
            clickTimestamps.removeFirst();
        }
        
        this.lastClickTime = currentTime;
        updateCPS();
    }
    
    private void updateCPS() {
        long currentTime = System.currentTimeMillis();
        long oneSecondAgo = currentTime - 1000;
        
        this.cps = (int) clickTimestamps.stream()
                .filter(time -> time > oneSecondAgo)
                .count();
    }
    
    public Deque<Long> getClickTimestamps() {
        return clickTimestamps;
    }
    
    public Deque<Long> getClickDelays() {
        return clickDelays;
    }
    
    public long getLastClickTime() {
        return lastClickTime;
    }
    
    public int getCPS() {
        updateCPS();
        return cps;
    }
}
