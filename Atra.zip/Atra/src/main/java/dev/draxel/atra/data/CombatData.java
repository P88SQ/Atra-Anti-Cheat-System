package dev.draxel.atra.data;

import org.bukkit.entity.Entity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;

public class CombatData {
    
    private final Deque<Long> clickTimes;
    private final Deque<Double> reachDistances;
    
    private Entity lastTarget;
    private UUID lastTargetUUID;
    private long lastAttackTime;
    private long lastHitTime;
    private int hitCount;
    private int missCount;
    
    private double lastYaw;
    private double lastPitch;
    private final Deque<Double> yawChanges;
    private final Deque<Double> pitchChanges;
    
    public CombatData() {
        this.clickTimes = new ArrayDeque<>();
        this.reachDistances = new ArrayDeque<>();
        this.yawChanges = new ArrayDeque<>();
        this.pitchChanges = new ArrayDeque<>();
        
        this.lastAttackTime = 0;
        this.lastHitTime = 0;
        this.hitCount = 0;
        this.missCount = 0;
    }
    
    public void addClick(long time) {
        clickTimes.add(time);
        if (clickTimes.size() > 100) {
            clickTimes.removeFirst();
        }
    }
    
    public void addReach(double distance) {
        reachDistances.add(distance);
        if (reachDistances.size() > 50) {
            reachDistances.removeFirst();
        }
    }
    
    public void updateRotation(double yaw, double pitch) {
        if (lastYaw != 0) {
            yawChanges.add(Math.abs(yaw - lastYaw));
            if (yawChanges.size() > 20) {
                yawChanges.removeFirst();
            }
        }
        
        if (lastPitch != 0) {
            pitchChanges.add(Math.abs(pitch - lastPitch));
            if (pitchChanges.size() > 20) {
                pitchChanges.removeFirst();
            }
        }
        
        this.lastYaw = yaw;
        this.lastPitch = pitch;
    }
    
    public Deque<Long> getClickTimes() {
        return clickTimes;
    }
    
    public Deque<Double> getReachDistances() {
        return reachDistances;
    }
    
    public Deque<Double> getYawChanges() {
        return yawChanges;
    }
    
    public Deque<Double> getPitchChanges() {
        return pitchChanges;
    }
    
    public Entity getLastTarget() {
        return lastTarget;
    }
    
    public void setLastTarget(Entity target) {
        this.lastTarget = target;
        this.lastTargetUUID = target != null ? target.getUniqueId() : null;
    }
    
    public UUID getLastTargetUUID() {
        return lastTargetUUID;
    }
    
    public long getLastAttackTime() {
        return lastAttackTime;
    }
    
    public void setLastAttackTime(long time) {
        this.lastAttackTime = time;
    }
    
    public long getLastHitTime() {
        return lastHitTime;
    }
    
    public void setLastHitTime(long time) {
        this.lastHitTime = time;
    }
    
    public int getHitCount() {
        return hitCount;
    }
    
    public void incrementHitCount() {
        this.hitCount++;
    }
    
    public int getMissCount() {
        return missCount;
    }
    
    public void incrementMissCount() {
        this.missCount++;
    }
    
    public void resetCombat() {
        this.hitCount = 0;
        this.missCount = 0;
        this.lastTarget = null;
        this.lastTargetUUID = null;
    }
}
