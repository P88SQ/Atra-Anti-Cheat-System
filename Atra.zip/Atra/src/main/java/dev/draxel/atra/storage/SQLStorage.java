package dev.draxel.atra.storage;

import dev.draxel.atra.AtraAC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLStorage {
    
    private final AtraAC plugin;
    private Connection connection;
    
    public SQLStorage(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public void connect(String host, int port, String database, String username, String password) {
        try {
            String url = String.format("jdbc:mysql://%s:%d/%s", host, port, database);
            connection = DriverManager.getConnection(url, username, password);
            
            plugin.getLogger().info("Connected to MySQL database!");
        } catch (SQLException e) {
            plugin.getLogger().severe("Failed to connect to MySQL database!");
            e.printStackTrace();
        }
    }
    
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public Connection getConnection() {
        return connection;
    }
}
