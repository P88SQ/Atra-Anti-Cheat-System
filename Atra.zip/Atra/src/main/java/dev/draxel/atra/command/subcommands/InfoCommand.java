package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.data.ViolationData;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class InfoCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public InfoCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.translate("<red>Használat: /atra info <játékos></red>"));
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ColorUtil.translate("<red>Játékos nem található!</red>"));
            return true;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Player Information – " + target.getName() + "</white></gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Ping:</white> " + target.getPing() + "ms</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>CPS:</white> " + data.getClickData().getCPS() + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Game Mode:</white> " + target.getGameMode() + "</gray>"));
        
        int totalViolations = 0;
        for (ViolationData vl : data.getAllViolations().values()) {
            totalViolations += vl.getViolations();
        }
        
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Total Violations:</white> " + totalViolations + "</gray>"));
        
        if (totalViolations > 0) {
            sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Violations by Check:</white></gray>"));
            for (ViolationData vl : data.getAllViolations().values()) {
                if (vl.getViolations() > 0) {
                    sender.sendMessage(ColorUtil.translate(
                        String.format("<blue>Atra <gray>|   • <white>%s</white>: <red>%d</red></gray>", 
                        vl.getCheckName(), vl.getViolations())
                    ));
                }
            }
        }
        
        return true;
    }
    
    @Override
    public String getName() {
        return "info";
    }
    
    @Override
    public String getPermission() {
        return "atra.info";
    }
}
