package dev.draxel.atra.command.subcommands;

import org.bukkit.command.CommandSender;

public interface SubCommand {
    
    boolean execute(CommandSender sender, String[] args);
    
    String getName();
    
    String getPermission();
}
