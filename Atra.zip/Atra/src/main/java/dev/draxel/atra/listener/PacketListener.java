package dev.draxel.atra.listener;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.packet.BadPacketsCheck;
import dev.draxel.atra.check.packet.TimerCheck;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.PacketUtil;
import dev.draxel.atra.util.PermissionUtil;
import org.bukkit.entity.Player;

public class PacketListener {
    
    private final AtraAC plugin;
    private PacketAdapter adapter;
    
    public PacketListener(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    public void register() {
        final AtraAC atraPlugin = plugin;
        
        adapter = new PacketAdapter(plugin, ListenerPriority.NORMAL,
                PacketType.Play.Client.POSITION,
                PacketType.Play.Client.POSITION_LOOK,
                PacketType.Play.Client.LOOK,
                PacketType.Play.Client.FLYING) {
            
            @Override
            public void onPacketReceiving(PacketEvent event) {
                Player player = event.getPlayer();
                if (PermissionUtil.hasBypass(player)) return;
                
                PlayerData data = atraPlugin.getPlayerDataManager().getPlayerData(player);
                data.incrementPacketCount();
                
                // Timer check
                TimerCheck timerCheck = (TimerCheck) atraPlugin.getCheckManager().getCheck("timer");
                if (timerCheck != null) {
                    timerCheck.checkTimer(player);
                }
                
                // BadPackets check
                BadPacketsCheck badPacketsCheck = (BadPacketsCheck) atraPlugin.getCheckManager().getCheck("badpackets");
                if (badPacketsCheck != null && event.getPacketType() == PacketType.Play.Client.POSITION_LOOK) {
                    try {
                        float pitch = event.getPacket().getFloat().read(1);
                        badPacketsCheck.checkInvalidPitch(player, pitch);
                    } catch (Exception e) {
                        // Ignore
                    }
                }
            }
        };
        
        ProtocolLibrary.getProtocolManager().addPacketListener(adapter);
    }
    
    public void unregister() {
        if (adapter != null) {
            ProtocolLibrary.getProtocolManager().removePacketListener(adapter);
        }
    }
}
