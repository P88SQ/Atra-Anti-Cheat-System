package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.prediction.BehaviorAnalyzer;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BehaviorCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public BehaviorCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ColorUtil.color("&cUsage: /atra behavior <player>"));
            return false;
        }
        
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ColorUtil.color("&cPlayer not found!"));
            return false;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        BehaviorAnalyzer.BehaviorAnalysisResult result = BehaviorAnalyzer.analyzeBehavior(target, data);
        
        sender.sendMessage(ColorUtil.color("&8&m                                    "));
        sender.sendMessage(ColorUtil.color("&6&lBehavior Analysis: &f" + target.getName()));
        sender.sendMessage(ColorUtil.color("&8&m                                    "));
        sender.sendMessage("");
        sender.sendMessage(ColorUtil.color("&eAnomaly Score: &f" + String.format("%.2f", result.anomalyScore)));
        sender.sendMessage(ColorUtil.color("&eHistorical Average: &f" + String.format("%.2f", result.historicalAverage)));
        sender.sendMessage("");
        
        if (result.anomalyScore > 0.7) {
            sender.sendMessage(ColorUtil.color("&cRisk Level: &4HIGH"));
        } else if (result.anomalyScore > 0.4) {
            sender.sendMessage(ColorUtil.color("&cRisk Level: &6MEDIUM"));
        } else {
            sender.sendMessage(ColorUtil.color("&cRisk Level: &aLOW"));
        }
        
        sender.sendMessage("");
        sender.sendMessage(ColorUtil.color("&eDetected Anomalies:"));
        if (result.reason.isEmpty()) {
            sender.sendMessage(ColorUtil.color("&7  None"));
        } else {
            String[] anomalies = result.reason.split("; ");
            for (String anomaly : anomalies) {
                sender.sendMessage(ColorUtil.color("&7  • &f" + anomaly));
            }
        }
        
        sender.sendMessage("");
        sender.sendMessage(ColorUtil.color("&8&m                                    "));
        return true;
    }
    
    @Override
    public String getName() {
        return "behavior";
    }
    
    @Override
    public String getPermission() {
        return "atra.command.behavior";
    }
}
