package dev.draxel.atra.util.update;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.util.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CompletableFuture;

public class UpdateChecker {
    
    private final AtraAC plugin;
    private final String currentVersion;
    private final int resourceId = 130303; // Spigot resource ID
    private final String spigotUrl = "https://www.spigotmc.org/resources/atra-anti-cheat-advanced-anti-cheat-system-1-8-1-21-4.130303/";
    
    private String latestVersion;
    private boolean updateAvailable;
    
    public UpdateChecker(AtraAC plugin) {
        this.plugin = plugin;
        this.currentVersion = plugin.getDescription().getVersion();
        this.updateAvailable = false;
    }
    
    public CompletableFuture<UpdateResult> checkForUpdates() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Spigot API endpoint
                String apiUrl = "https://api.spiget.org/v2/resources/" + resourceId + "/versions/latest";
                
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestProperty("User-Agent", "Atra-AntiCheat");
                
                int responseCode = connection.getResponseCode();
                
                if (responseCode == 200) {
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream())
                    );
                    
                    StringBuilder response = new StringBuilder();
                    String line;
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    
                    reader.close();
                    
                    // Parse JSON response from Spiget API
                    String jsonResponse = response.toString();
                    latestVersion = extractVersionFromSpiget(jsonResponse);
                    
                    if (latestVersion != null && !latestVersion.equals(currentVersion)) {
                        updateAvailable = true;
                        return new UpdateResult(true, latestVersion, spigotUrl);
                    }
                    
                    return new UpdateResult(false, currentVersion, null);
                }
                
            } catch (Exception e) {
                Logger.warning("Failed to check for updates: " + e.getMessage());
            }
            
            return new UpdateResult(false, currentVersion, null);
        });
    }
    
    private String extractVersionFromSpiget(String json) {
        try {
            // Spiget API returns: {"id":123456,"name":"1.0.0"}
            int nameIndex = json.indexOf("\"name\"");
            if (nameIndex != -1) {
                int startQuote = json.indexOf("\"", nameIndex + 7);
                int endQuote = json.indexOf("\"", startQuote + 1);
                return json.substring(startQuote + 1, endQuote);
            }
        } catch (Exception e) {
            Logger.warning("Failed to parse version from Spiget API");
        }
        return null;
    }
    
    public void notifyAdmins() {
        if (!updateAvailable) return;
        
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.hasPermission("atra.admin")) {
                        player.sendMessage("§8[§bAtra§8] §7━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                        player.sendMessage("§8[§bAtra§8] §fNew update available!");
                        player.sendMessage("§8[§bAtra§8] §7Current: §f" + currentVersion);
                        player.sendMessage("§8[§bAtra§8] §7Latest: §a" + latestVersion);
                        player.sendMessage("§8[§bAtra§8] §7Download: §b" + spigotUrl);
                        player.sendMessage("§8[§bAtra§8] §7━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                    }
                }
            }
        }.runTask(plugin);
    }
    
    public void startAutoCheck() {
        // Check every 6 hours
        new BukkitRunnable() {
            @Override
            public void run() {
                checkForUpdates().thenAccept(result -> {
                    if (result.isUpdateAvailable()) {
                        Logger.info("Update available: " + result.getLatestVersion());
                        notifyAdmins();
                    }
                });
            }
        }.runTaskTimerAsynchronously(plugin, 0L, 20L * 60 * 60 * 6); // Every 6 hours
    }
    
    public boolean isUpdateAvailable() {
        return updateAvailable;
    }
    
    public String getLatestVersion() {
        return latestVersion;
    }
    
    public String getSpigotUrl() {
        return spigotUrl;
    }
    
    public String getCurrentVersion() {
        return currentVersion;
    }
    
    public static class UpdateResult {
        private final boolean updateAvailable;
        private final String latestVersion;
        private final String downloadUrl;
        
        public UpdateResult(boolean updateAvailable, String latestVersion, String downloadUrl) {
            this.updateAvailable = updateAvailable;
            this.latestVersion = latestVersion;
            this.downloadUrl = downloadUrl;
        }
        
        public boolean isUpdateAvailable() {
            return updateAvailable;
        }
        
        public String getLatestVersion() {
            return latestVersion;
        }
        
        public String getDownloadUrl() {
            return downloadUrl;
        }
    }
}
