package dev.draxel.atra.command.subcommands;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.util.ColorUtil;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements SubCommand {
    
    private final AtraAC plugin;
    
    public ReloadCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean execute(CommandSender sender, String[] args) {
        long startTime = System.currentTimeMillis();
        plugin.getConfigManager().reloadConfigs();
        long loadTime = System.currentTimeMillis() - startTime;
        
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Configuration reloaded in " + loadTime + "ms</white></gray>"));
        
        return true;
    }
    
    @Override
    public String getName() {
        return "reload";
    }
    
    @Override
    public String getPermission() {
        return "atra.reload";
    }
}
