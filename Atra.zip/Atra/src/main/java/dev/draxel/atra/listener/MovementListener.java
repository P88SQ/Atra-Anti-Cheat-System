package dev.draxel.atra.listener;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.movement.*;
import dev.draxel.atra.data.MovementData;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.util.PermissionUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class MovementListener implements Listener {
    
    private final AtraAC plugin;
    
    public MovementListener(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (PermissionUtil.hasBypass(player)) return;
        
        // Skip if no actual movement
        if (event.getFrom().getX() == event.getTo().getX() &&
            event.getFrom().getY() == event.getTo().getY() &&
            event.getFrom().getZ() == event.getTo().getZ()) {
            return;
        }
        
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(player);
        MovementData movementData = data.getMovementData();
        
        // Update movement data
        movementData.updateLocation(event.getTo(), player.isOnGround());
        
        // Run checks
        SpeedCheck speedCheck = (SpeedCheck) plugin.getCheckManager().getCheck("speed");
        if (speedCheck != null) {
            speedCheck.checkSpeed(player);
        }
        
        FlyCheck flyCheck = (FlyCheck) plugin.getCheckManager().getCheck("fly");
        if (flyCheck != null) {
            flyCheck.checkFly(player);
        }
        
        NoClipCheck noClipCheck = (NoClipCheck) plugin.getCheckManager().getCheck("noclip");
        if (noClipCheck != null) {
            noClipCheck.checkNoClip(player);
        }
        
        StepCheck stepCheck = (StepCheck) plugin.getCheckManager().getCheck("step");
        if (stepCheck != null) {
            stepCheck.checkStep(player);
        }
        
        JesusCheck jesusCheck = (JesusCheck) plugin.getCheckManager().getCheck("jesus");
        if (jesusCheck != null) {
            jesusCheck.checkJesus(player);
        }
        
        ElytraCheck elytraCheck = (ElytraCheck) plugin.getCheckManager().getCheck("elytra");
        if (elytraCheck != null) {
            elytraCheck.checkElytra(player);
        }
    }
}
