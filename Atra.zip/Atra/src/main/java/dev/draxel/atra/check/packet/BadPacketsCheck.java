package dev.draxel.atra.check.packet;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.check.CheckType;
import org.bukkit.entity.Player;

public class BadPacketsCheck extends Check {
    
    public BadPacketsCheck(AtraAC plugin) {
        super(plugin, "BadPackets", CheckType.PACKET);
    }
    
    public void checkInvalidPitch(Player player, float pitch) {
        if (!enabled) return;
        
        if (Math.abs(pitch) > 90.0f) {
            flag(player, String.format("Invalid pitch: %.2f", pitch), 20);
        }
    }
    
    public void checkInvalidPosition(Player player, double x, double y, double z) {
        if (!enabled) return;
        
        if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z) ||
            Double.isInfinite(x) || Double.isInfinite(y) || Double.isInfinite(z)) {
            
            flag(player, "Invalid position values", 50);
        }
    }
}
