package dev.draxel.atra.api.interfaces;

import dev.draxel.atra.check.CheckType;

public interface ICheck {
    
    String getName();
    
    CheckType getType();
    
    boolean isEnabled();
    
    void setEnabled(boolean enabled);
    
    int getMaxViolations();
}
