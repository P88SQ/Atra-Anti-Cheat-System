package dev.draxel.atra.storage;

import dev.draxel.atra.AtraAC;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public class FlatFileStorage {
    
    private final AtraAC plugin;
    private final File dataFolder;
    
    public FlatFileStorage(AtraAC plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "data");
        
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }
    
    public void saveData(String fileName, YamlConfiguration data) {
        File file = new File(dataFolder, fileName + ".yml");
        
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save data: " + fileName);
            e.printStackTrace();
        }
    }
    
    public YamlConfiguration loadData(String fileName) {
        File file = new File(dataFolder, fileName + ".yml");
        
        if (!file.exists()) {
            return new YamlConfiguration();
        }
        
        return YamlConfiguration.loadConfiguration(file);
    }
}
