package dev.draxel.atra.command;

import dev.draxel.atra.AtraAC;
import dev.draxel.atra.api.AtraAPI;
import dev.draxel.atra.check.Check;
import dev.draxel.atra.data.PlayerData;
import dev.draxel.atra.data.ViolationData;
import dev.draxel.atra.util.ColorUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AtraCommand implements CommandExecutor, TabCompleter {
    
    private final AtraAC plugin;
    
    public AtraCommand(AtraAC plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "alerts":
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Csak játékosok használhatják!");
                    return true;
                }
                
                if (!sender.hasPermission("atra.alerts")) {
                    sender.sendMessage(ColorUtil.translate("<red>Nincs jogosultságod!</red>"));
                    return true;
                }
                
                plugin.getAlertManager().toggleAlerts((Player) sender);
                break;
                
            case "info":
                if (args.length < 2) {
                    sender.sendMessage(ColorUtil.translate("<red>Használat: /atra info <játékos></red>"));
                    return true;
                }
                
                if (!sender.hasPermission("atra.info")) {
                    sender.sendMessage(ColorUtil.translate("<red>Nincs jogosultságod!</red>"));
                    return true;
                }
                
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(ColorUtil.translate("<red>Játékos nem található!</red>"));
                    return true;
                }
                
                showInfo(sender, target);
                break;
                
            case "reset":
                if (args.length < 2) {
                    sender.sendMessage(ColorUtil.translate("<red>Használat: /atra reset <játékos> [check]</red>"));
                    return true;
                }
                
                if (!sender.hasPermission("atra.reset")) {
                    sender.sendMessage(ColorUtil.translate("<red>Nincs jogosultságod!</red>"));
                    return true;
                }
                
                Player resetTarget = Bukkit.getPlayer(args[1]);
                if (resetTarget == null) {
                    sender.sendMessage(ColorUtil.translate("<red>Játékos nem található!</red>"));
                    return true;
                }
                
                if (args.length >= 3) {
                    AtraAPI.resetViolations(resetTarget, args[2]);
                    sender.sendMessage(ColorUtil.translate(
                        String.format("<green>%s violation-jei resetelve: %s</green>", resetTarget.getName(), args[2])
                    ));
                } else {
                    AtraAPI.resetAllViolations(resetTarget);
                    sender.sendMessage(ColorUtil.translate(
                        String.format("<green>%s összes violation-je resetelve</green>", resetTarget.getName())
                    ));
                }
                break;
                
            case "reload":
                if (!sender.hasPermission("atra.reload")) {
                    sender.sendMessage(ColorUtil.translate("<red>Nincs jogosultságod!</red>"));
                    return true;
                }
                
                plugin.getConfigManager().reloadConfigs();
                sender.sendMessage(ColorUtil.translate("<green>Config újratöltve!</green>"));
                break;
                
            case "version":
                showVersion(sender);
                break;
                
            default:
                sendHelp(sender);
                break;
        }
        
        return true;
    }
    
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Atra Anticheat – Command help</white></gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra reload</white> – Reloads the config</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra alerts</white> – Toggles the alerts</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra version</white> – View version info</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra debug</white> – Performance analysis</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra info <player></white> – Get user's info</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>/atra reset <player> [check]</white> – Reset violations</gray>"));
    }
    
    private void showInfo(CommandSender sender, Player target) {
        PlayerData data = plugin.getPlayerDataManager().getPlayerData(target);
        
        sender.sendMessage(ColorUtil.translate("<gray>========== <white>" + target.getName() + "</white> ==========</gray>"));
        sender.sendMessage(ColorUtil.translate("<yellow>Ping:</yellow> <white>" + target.getPing() + "ms</white>"));
        sender.sendMessage(ColorUtil.translate("<yellow>CPS:</yellow> <white>" + data.getClickData().getCPS() + "</white>"));
        sender.sendMessage(ColorUtil.translate("<yellow>Violations:</yellow>"));
        
        for (ViolationData vl : data.getAllViolations().values()) {
            if (vl.getViolations() > 0) {
                sender.sendMessage(ColorUtil.translate(
                    String.format("  <gray>- <white>%s</white>: <red>%d</red></gray>", vl.getCheckName(), vl.getViolations())
                ));
            }
        }
    }
    
    private void showVersion(CommandSender sender) {
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Version Information</white></gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Version:</white> " + plugin.getDescription().getVersion() + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Build:</white> 1.0.0</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Server:</white> " + plugin.getServer().getVersion() + "</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>Checks:</white> " + plugin.getCheckManager().getChecks().size() + " active</gray>"));
        sender.sendMessage(ColorUtil.translate("<blue>Atra <gray>| <white>TPS:</white> " + String.format("%.2f", plugin.getServer().getTPS()[0]) + "</gray>"));
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("alerts", "info", "reset", "reload", "version", "debug").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        
        if (args.length == 2 && (args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("reset"))) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        
        if (args.length == 3 && args[0].equalsIgnoreCase("reset")) {
            return plugin.getCheckManager().getChecks().stream()
                    .map(Check::getName)
                    .filter(s -> s.toLowerCase().startsWith(args[2].toLowerCase()))
                    .collect(Collectors.toList());
        }
        
        return new ArrayList<>();
    }
}
